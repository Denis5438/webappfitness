import { Star, Download } from 'lucide-react';
import BottomNav from '../components/BottomNav';

const programs = [
  {
    id: 1,
    title: 'Силовая Эстетика 2.0',
    author: 'Coach Mike',
    rating: 4.9,
    price: 2990,
    description: '12-недельная программа для набора мышечной массы с акцентом на плечи.',
    badge: 'BESTSELLER',
    badgeColor: 'bg-yellow-400 text-yellow-900',
  },
  {
    id: 2,
    title: 'Основы Фитнеса',
    author: 'FitMarket Team',
    rating: 4.7,
    price: 0,
    description: 'Базовая программа фулбоди для новичков.',
    badge: 'БЕСПЛАТНО',
    badgeColor: 'bg-green-500 text-white',
  },
  {
    id: 3,
    title: 'Жиросжигание PRO',
    author: 'Anna Fitness',
    rating: 4.8,
    price: 1990,
    description: '8-недельная программа для эффективного похудения.',
    badge: null,
  },
];

export default function Marketplace() {
  return (
    <div className="app bg-gray-50 min-h-screen">
      {/* Header */}
      <header className="bg-white px-4 py-4 mb-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">
            Fit<span className="text-primary">Market</span>
          </h1>
          <div className="flex gap-2">
            <button className="px-4 py-2 rounded-lg border border-gray-200 text-sm font-medium">
              Атлет
            </button>
            <button className="px-4 py-2 rounded-lg bg-gray-100 text-sm font-medium">
              Тренер
            </button>
          </div>
        </div>
      </header>

      <div className="px-4 pb-20">
        <h2 className="text-2xl font-bold mb-4">Магазин Программ</h2>

        <div className="space-y-4">
          {programs.map((program) => (
            <div key={program.id} className="bg-white rounded-2xl p-4 shadow-sm">
              {/* Badge and Price */}
              <div className="flex items-center justify-between mb-3">
                {program.badge && (
                  <span className={`px-3 py-1 rounded-lg text-xs font-bold ${program.badgeColor}`}>
                    {program.badge}
                  </span>
                )}
                <span className="text-xl font-bold text-green-600 ml-auto">
                  {program.price === 0 ? '0 ₽' : `${program.price.toLocaleString()} ₽`}
                </span>
              </div>

              {/* Title */}
              <h3 className="text-lg font-bold text-gray-900 mb-2">{program.title}</h3>

              {/* Author and Rating */}
              <div className="flex items-center gap-2 mb-3">
                <span className="text-sm text-gray-500">Автор: {program.author}</span>
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm font-medium">{program.rating}</span>
                </div>
              </div>

              {/* Description */}
              <p className="text-sm text-gray-600 mb-4">{program.description}</p>

              {/* Action Button */}
              <button className="w-full py-3 border-2 border-primary text-primary rounded-xl font-semibold hover:bg-primary hover:text-white transition-colors flex items-center justify-center gap-2">
                {program.price === 0 ? (
                  <>
                    <Download className="w-5 h-5" />
                    Скачать
                  </>
                ) : (
                  'Подробнее'
                )}
              </button>
            </div>
          ))}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
