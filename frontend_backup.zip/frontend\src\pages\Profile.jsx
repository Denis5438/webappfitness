import { useTelegram } from '../hooks/useTelegram';
import { Settings, LogOut, Crown, TrendingUp } from 'lucide-react';
import BottomNav from '../components/BottomNav';

export default function Profile() {
  const { user } = useTelegram();

  return (
    <div className="app bg-gray-50 min-h-screen">
      {/* Header */}
      <header className="bg-white px-4 py-4 mb-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">
            Fit<span className="text-primary">Market</span>
          </h1>
          <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <Settings className="w-6 h-6 text-gray-600" />
          </button>
        </div>
      </header>

      <div className="px-4 pb-20">
        {/* Profile Card */}
        <div className="bg-gradient-to-br from-primary to-primary-dark rounded-2xl p-6 text-white mb-4 shadow-lg">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center text-2xl font-bold">
              {user?.first_name?.[0] || 'U'}
            </div>
            <div>
              <h2 className="text-xl font-bold">{user?.first_name || 'Пользователь'}</h2>
              <p className="text-primary-light">@{user?.username || 'user'}</p>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-white/20">
            <div>
              <div className="text-sm opacity-80">Текущий баланс</div>
              <div className="text-2xl font-bold">14 500 ₽</div>
            </div>
            <div className="flex gap-2">
              <button className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-medium transition-colors">
                Вывести
              </button>
              <button className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-medium transition-colors">
                История
              </button>
            </div>
          </div>
        </div>

        {/* Programs Section */}
        <section className="bg-white rounded-2xl p-4 shadow-sm mb-4">
          <h3 className="text-lg font-bold mb-4">Мои программы</h3>
          
          <div className="border border-gray-100 rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold">Жим 100кг за месяц</h4>
              <span className="text-green-600 font-bold">+22 500 ₽</span>
            </div>
            <p className="text-sm text-gray-500 mb-4">15 продаж • 1 500 ₽</p>
            <div className="flex gap-2">
              <button className="flex-1 py-2 text-primary border border-primary rounded-lg text-sm font-medium hover:bg-primary hover:text-white transition-colors">
                Редактировать
              </button>
              <button className="flex-1 py-2 text-gray-600 border border-gray-200 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors">
                Скрыть
              </button>
            </div>
          </div>

          <button className="w-full mt-4 py-3 bg-green-500 text-white rounded-xl font-semibold hover:bg-green-600 transition-colors">
            + Создать программу
          </button>
        </section>

        {/* Stats */}
        <section className="bg-white rounded-2xl p-4 shadow-sm mb-4">
          <h3 className="text-lg font-bold mb-4">Статистика</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-gray-50 rounded-xl p-3 text-center">
              <TrendingUp className="w-6 h-6 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold">156</div>
              <div className="text-xs text-gray-500">Тренировок</div>
            </div>
            <div className="bg-gray-50 rounded-xl p-3 text-center">
              <Crown className="w-6 h-6 text-yellow-500 mx-auto mb-2" />
              <div className="text-2xl font-bold">12</div>
              <div className="text-xs text-gray-500">Рекордов</div>
            </div>
          </div>
        </section>

        {/* Logout */}
        <button className="w-full py-3 border border-red-200 text-red-600 rounded-xl font-semibold hover:bg-red-50 transition-colors flex items-center justify-center gap-2">
          <LogOut className="w-5 h-5" />
          Выйти
        </button>
      </div>

      <BottomNav />
    </div>
  );
}
