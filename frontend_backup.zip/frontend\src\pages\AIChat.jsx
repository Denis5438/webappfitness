import { useState, useEffect, useRef } from 'react';
import { useTelegram } from '../hooks/useTelegram';
import { aiApi } from '../services/api';

export default function AIChat() {
  const { user } = useTelegram();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [remaining, setRemaining] = useState(10);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (user) {
      loadHistory();
    }
  }, [user]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const loadHistory = async () => {
    try {
      const res = await aiApi.getHistory(user.id, 20);
      setMessages(res.data);
    } catch (error) {
      console.error('Error loading history:', error);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || !user || loading) return;

    const userMessage = input.trim();
    setInput('');
    setLoading(true);

    setMessages(prev => [...prev, {
      role: 'user',
      content: userMessage,
      created_at: new Date().toISOString()
    }]);

    try {
      const res = await aiApi.sendMessage(user.id, userMessage);

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: res.data.response,
        created_at: new Date().toISOString()
      }]);

      setRemaining(res.data.remaining);
    } catch (error) {
      console.error('Error sending message:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'Извините, произошла ошибка. Попробуйте позже.',
        created_at: new Date().toISOString()
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100vh',
      background: '#f4f4f5'
    }}>
      <div style={{
        padding: '16px',
        background: 'white',
        borderBottom: '1px solid #e5e5e5',
        position: 'sticky',
        top: 0,
        zIndex: 10
      }}>
        <h2 style={{ margin: 0 }}>🤖 AI Коуч</h2>
        <p style={{ margin: '4px 0 0 0', fontSize: '14px', color: '#666' }}>
          Осталось запросов: {remaining === -1 ? '∞' : remaining}
        </p>
      </div>

      <div style={{
        flex: 1,
        overflowY: 'auto',
        padding: '16px',
        paddingBottom: '80px'
      }}>
        {messages.length === 0 ? (
          <div style={{ textAlign: 'center', color: '#999', marginTop: '40px' }}>
            <p>👋 Привет! Я твой AI фитнес-коуч.</p>
            <p>Задай мне вопрос о тренировках!</p>
          </div>
        ) : (
          messages.map((msg, idx) => (
            <div
              key={idx}
              style={{
                marginBottom: '12px',
                display: 'flex',
                justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start'
              }}
            >
              <div
                style={{
                  maxWidth: '80%',
                  padding: '12px 16px',
                  borderRadius: '16px',
                  background: msg.role === 'user' ? '#3390ec' : 'white',
                  color: msg.role === 'user' ? 'white' : 'black',
                  boxShadow: '0 1px 2px rgba(0,0,0,0.1)'
                }}
              >
                {msg.content}
              </div>
            </div>
          ))
        )}
        {loading && (
          <div style={{ textAlign: 'center', color: '#999' }}>
            <p>AI думает...</p>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div style={{
        padding: '16px',
        background: 'white',
        borderTop: '1px solid #e5e5e5',
        position: 'sticky',
        bottom: 0
      }}>
        <div style={{ display: 'flex', gap: '8px' }}>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Задайте вопрос..."
            disabled={loading}
            style={{
              flex: 1,
              padding: '12px',
              borderRadius: '24px',
              border: '1px solid #e5e5e5',
              fontSize: '14px'
            }}
          />
          <button
            onClick={handleSend}
            disabled={loading || !input.trim()}
            style={{
              padding: '12px 24px',
              borderRadius: '24px',
              background: '#3390ec',
              color: 'white',
              border: 'none',
              cursor: loading || !input.trim() ? 'not-allowed' : 'pointer',
              opacity: loading || !input.trim() ? 0.5 : 1
            }}
          >
            →
          </button>
        </div>
      </div>
    </div>
  );
}
