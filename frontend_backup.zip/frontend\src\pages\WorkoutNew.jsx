import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTelegram } from '../hooks/useTelegram';
import { workoutsApi } from '../services/api';

export default function WorkoutNew() {
  const navigate = useNavigate();
  const { user, hapticFeedback } = useTelegram();
  const [exercises, setExercises] = useState([
    { exercise_name: '', muscle_group: '', sets: [{ set: 1, weight: 0, reps: 0 }] }
  ]);
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const addExercise = () => {
    setExercises([...exercises, {
      exercise_name: '',
      muscle_group: '',
      sets: [{ set: 1, weight: 0, reps: 0 }]
    }]);
  };

  const addSet = (exerciseIndex) => {
    const newExercises = [...exercises];
    const setNumber = newExercises[exerciseIndex].sets.length + 1;
    newExercises[exerciseIndex].sets.push({ set: setNumber, weight: 0, reps: 0 });
    setExercises(newExercises);
  };

  const updateExercise = (index, field, value) => {
    const newExercises = [...exercises];
    newExercises[index][field] = value;
    setExercises(newExercises);
  };

  const updateSet = (exerciseIndex, setIndex, field, value) => {
    const newExercises = [...exercises];
    newExercises[exerciseIndex].sets[setIndex][field] = parseFloat(value) || 0;
    setExercises(newExercises);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    try {
      await workoutsApi.createWorkout({
        user_id: user.id,
        date: new Date().toISOString().split('T')[0],
        notes,
        exercises: exercises.filter(ex => ex.exercise_name)
      });
      
      hapticFeedback('success');
      navigate('/');
    } catch (error) {
      console.error('Error creating workout:', error);
      alert('Ошибка при сохранении тренировки');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '16px', paddingBottom: '80px' }}>
      <h1>Новая тренировка</h1>
      
      <form onSubmit={handleSubmit}>
        {exercises.map((exercise, exIndex) => (
          <div key={exIndex} style={{ 
            background: '#f4f4f5', 
            padding: '16px', 
            borderRadius: '12px', 
            marginBottom: '16px' 
          }}>
            <input
              type="text"
              placeholder="Название упражнения"
              value={exercise.exercise_name}
              onChange={(e) => updateExercise(exIndex, 'exercise_name', e.target.value)}
              style={{ width: '100%', padding: '8px', marginBottom: '8px', borderRadius: '8px', border: '1px solid #ddd' }}
            />
            
            <input
              type="text"
              placeholder="Группа мышц"
              value={exercise.muscle_group}
              onChange={(e) => updateExercise(exIndex, 'muscle_group', e.target.value)}
              style={{ width: '100%', padding: '8px', marginBottom: '12px', borderRadius: '8px', border: '1px solid #ddd' }}
            />

            {exercise.sets.map((set, setIndex) => (
              <div key={setIndex} style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
                <span style={{ padding: '8px', minWidth: '40px' }}>#{set.set}</span>
                <input
                  type="number"
                  placeholder="Вес"
                  value={set.weight || ''}
                  onChange={(e) => updateSet(exIndex, setIndex, 'weight', e.target.value)}
                  style={{ flex: 1, padding: '8px', borderRadius: '8px', border: '1px solid #ddd' }}
                />
                <input
                  type="number"
                  placeholder="Повторения"
                  value={set.reps || ''}
                  onChange={(e) => updateSet(exIndex, setIndex, 'reps', e.target.value)}
                  style={{ flex: 1, padding: '8px', borderRadius: '8px', border: '1px solid #ddd' }}
                />
              </div>
            ))}

            <button
              type="button"
              onClick={() => addSet(exIndex)}
              style={{ 
                width: '100%', 
                padding: '8px', 
                marginTop: '8px',
                background: 'white',
                border: '1px dashed #3390ec',
                borderRadius: '8px',
                color: '#3390ec',
                cursor: 'pointer'
              }}
            >
              + Добавить подход
            </button>
          </div>
        ))}

        <button
          type="button"
          onClick={addExercise}
          style={{ 
            width: '100%', 
            padding: '12px', 
            marginBottom: '16px',
            background: '#f4f4f5',
            border: 'none',
            borderRadius: '12px',
            cursor: 'pointer'
          }}
        >
          + Добавить упражнение
        </button>

        <textarea
          placeholder="Заметки о тренировке"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          style={{ 
            width: '100%', 
            padding: '12px', 
            marginBottom: '16px',
            borderRadius: '12px',
            border: '1px solid #ddd',
            minHeight: '80px'
          }}
        />

        <button
          type="submit"
          disabled={loading}
          style={{ 
            width: '100%', 
            padding: '16px', 
            background: '#3390ec',
            color: 'white',
            border: 'none',
            borderRadius: '12px',
            fontSize: '16px',
            fontWeight: '600',
            cursor: loading ? 'not-allowed' : 'pointer',
            opacity: loading ? 0.5 : 1
          }}
        >
          {loading ? 'Сохранение...' : 'Сохранить тренировку'}
        </button>
      </form>
    </div>
  );
}
