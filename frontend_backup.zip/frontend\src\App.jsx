import React, { useState, useEffect, useRef } from 'react';
import {
  Dumbbell, ShoppingBag, User, Plus, Clock, Play, ChevronRight, ChevronLeft,
  MoreHorizontal, Search, Home, Star, Crown, Check, X, Trash2, Edit3, Save,
  Shield, UserCheck, UserX, Wallet, ArrowUpRight, ArrowDownLeft, History,
  MessageCircle, Send, Filter, BadgeCheck, Users, TrendingUp, Timer, Trophy,
  Minimize2, Maximize2, ChevronDown, Award, Bell, Settings, Camera, Upload
} from 'lucide-react';

const tg = window.Telegram?.WebApp;
const ADMIN_ID = 6540555219;

// Новогодние снежинки (оптимизированные)
const SNOWFLAKES = Array.from({ length: 12 }, (_, i) => ({
  id: i,
  left: `${(i * 8.3) % 100}%`,
  delay: `${i * 0.4}s`,
  duration: `${8 + (i % 5) * 2}s`,
  size: `${10 + (i % 4) * 4}px`,
}));

const Snowflakes = () => (
  <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
    {SNOWFLAKES.map((flake) => (
      <div
        key={flake.id}
        className="absolute text-white/60 animate-fall will-change-transform"
        style={{
          left: flake.left,
          animationDelay: flake.delay,
          animationDuration: flake.duration,
          fontSize: flake.size,
        }}
      >
        ❄
      </div>
    ))}
    <style>{`
      @keyframes fall {
        0% { transform: translateY(-20px) rotate(0deg); opacity: 0.6; }
        100% { transform: translateY(100vh) rotate(360deg); opacity: 0; }
      }
      .animate-fall { animation: fall linear infinite; }
    `}</style>
  </div>
);

// Список популярных упражнений по категориям
const EXERCISE_LIST = {
  'Грудь': ['Жим лёжа', 'Жим гантелей', 'Разводка гантелей', 'Отжимания', 'Жим в тренажёре', 'Кроссовер'],
  'Спина': ['Тяга штанги в наклоне', 'Подтягивания', 'Тяга верхнего блока', 'Тяга гантели', 'Становая тяга', 'Гиперэкстензия'],
  'Плечи': ['Жим стоя', 'Жим сидя', 'Махи гантелями в стороны', 'Махи перед собой', 'Тяга к подбородку'],
  'Руки': ['Подъём штанги на бицепс', 'Молотки', 'Французский жим', 'Разгибания на трицепс', 'Отжимания на брусьях'],
  'Ноги': ['Приседания со штангой', 'Жим ногами', 'Выпады', 'Разгибания ног', 'Сгибания ног', 'Подъём на носки'],
  'Кор': ['Планка', 'Скручивания', 'Подъём ног', 'Русские скручивания', 'Вакуум'],
  'Кардио': ['Бег', 'Велотренажёр', 'Эллипс', 'Скакалка', 'Бёрпи'],
};

const getTelegramUser = () => {
  if (tg?.initDataUnsafe?.user) {
    const u = tg.initDataUnsafe.user;
    return { id: u.id, firstName: u.first_name || '', lastName: u.last_name || '', username: u.username || '', photoUrl: u.photo_url || null };
  }
  return null;
};

const ConfirmationModal = ({ isOpen, title, message, onConfirm, onCancel, confirmText = 'Подтвердить', cancelText = 'Отмена', isDanger = true }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-black/80 z-[300] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#1a1a1a] border border-white/10 rounded-2xl p-6 max-w-sm w-full shadow-2xl transform scale-100 transition-all">
        <h3 className="text-xl font-bold mb-2 text-white">{title}</h3>
        <p className="text-gray-300 mb-6 whitespace-pre-wrap text-sm leading-relaxed">{message}</p>
        <div className="flex gap-3">
          <button onClick={onCancel} className="flex-1 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-white font-medium transition-colors">
            {cancelText}
          </button>
          <button onClick={onConfirm} className={`flex-1 py-3 rounded-xl text-white font-bold transition-colors shadow-lg ${isDanger ? 'bg-red-500 hover:bg-red-600 shadow-red-500/20' : 'bg-green-500 hover:bg-green-600 shadow-green-500/20'}`}>
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [confirmModal, setConfirmModal] = useState({ isOpen: false, title: '', message: '', onConfirm: null, isDanger: true, confirmText: 'Подтвердить' });
  const [lastReadSupportId, setLastReadSupportId] = useState(parseInt(localStorage.getItem('lastReadSupportId') || '0'));

  const openConfirm = (title, message, onConfirm, isDanger = true, confirmText = 'Подтвердить') => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      },
      isDanger,
      confirmText
    });
  };

  // Периодическая проверка сообщений поддержки
  useEffect(() => {
    if (user?.id) {
      fetchMySupportMessages();
      const interval = setInterval(fetchMySupportMessages, 30000);
      return () => clearInterval(interval);
    }
  }, [user?.id]);

  // Обновляем прочитанное при входе в таб
  useEffect(() => {
    if (activeTab === 'support' && userMessages.length > 0) {
      const lastMsg = userMessages[userMessages.length - 1];
      if (lastMsg.from === 'support') {
        const newId = lastMsg.id || Date.now();
        setLastReadSupportId(newId);
        localStorage.setItem('lastReadSupportId', newId);
      }
    }
  }, [activeTab, userMessages]);
  const [user, setUser] = useState(null);
  const [programs, setPrograms] = useState([]);
  const [purchasedPrograms, setPurchasedPrograms] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [needsRegistration, setNeedsRegistration] = useState(false); // Показать экран регистрации

  const [editingProgram, setEditingProgram] = useState(null);
  const [showProgramEditor, setShowProgramEditor] = useState(false);
  const [activeWorkout, setActiveWorkout] = useState(null);
  const [workoutMinimized, setWorkoutMinimized] = useState(false);
  const [workoutTimer, setWorkoutTimer] = useState(0);
  const timerRef = useRef(null);

  const [workoutHistory, setWorkoutHistory] = useState([]);
  const [viewingWorkout, setViewingWorkout] = useState(null);
  const [exerciseRecords, setExerciseRecords] = useState({});

  const [userRole, setUserRole] = useState('user');
  const [allUsers, setAllUsers] = useState([]);
  const [trainerRequests, setTrainerRequests] = useState([]);

  const [userBalance, setUserBalance] = useState(0);
  const [balanceHistory, setBalanceHistory] = useState([]);

  const [marketPrograms, setMarketPrograms] = useState([]);
  const [marketFilter, setMarketFilter] = useState('Все');
  const [searchQuery, setSearchQuery] = useState('');

  const [supportMessages, setSupportMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [activeChatUser, setActiveChatUser] = useState(null);

  // Настройки комиссии и вывода
  const [withdrawalFee, setWithdrawalFee] = useState(3); // % комиссии
  const [adminBalance, setAdminBalance] = useState(0); // Баланс админа от комиссий
  const [isWithdrawing, setIsWithdrawing] = useState(false);
  const [withdrawalRequests, setWithdrawalRequests] = useState([]); // Заявки на вывод
  const [appBalance, setAppBalance] = useState(null); // Баланс приложения CryptoBot

  // Уведомления и новости
  const [notifications, setNotifications] = useState([]); // Персональные уведомления
  const [news, setNews] = useState([]); // Новости от модераторов
  const [showNotificationsModal, setShowNotificationsModal] = useState(false);
  const [lastSeenNewsId, setLastSeenNewsId] = useState(''); // ID последней прочитанной новости (с сервера)
  const [showNewYearTheme, setShowNewYearTheme] = useState(true); // Новогодняя тема
  const [newProgramExercises, setNewProgramExercises] = useState([]); // Упражнения для новой программы

  // Настройки профиля
  const [showProfileSettings, setShowProfileSettings] = useState(false);
  const [profileDisplayName, setProfileDisplayName] = useState('');
  const [profileAvatarUrl, setProfileAvatarUrl] = useState('');
  const [profileSaving, setProfileSaving] = useState(false);

  // Итоги тренировки
  const [workoutSummary, setWorkoutSummary] = useState(null);

  useEffect(() => {
    if (tg) { tg.ready(); tg.expand(); }

    const tgUser = getTelegramUser();
    if (tgUser?.id) {
      setUser(tgUser);

      // Загружаем роль с сервера (не из localStorage!)
      const fetchMyUserInfo = async () => {
        try {
          console.log('🔍 Fetching user info from server...');
          const response = await fetch(`${API_URL}/user/me`, {
            headers: { 'x-telegram-init-data': getInitData() },
          });

          if (response.status === 403) {
            const data = await response.json();
            if (data.error === 'not_registered') {
              console.log('⚠️ User not registered. Needs to /start bot first.');
              setNeedsRegistration(true);
              setIsLoading(false);
              return;
            }
          }

          if (response.ok) {
            const data = await response.json();
            console.log('✅ User info from server:', data);
            if (data.user?.role) {
              const serverRole = data.user.role.toLowerCase(); // ADMIN -> admin, TRAINER -> trainer
              console.log('📋 Setting userRole from server:', serverRole);
              if (serverRole === 'admin' || serverRole === 'moderator') {
                setUserRole('moderator');
              } else if (serverRole === 'trainer') {
                setUserRole('trainer');
              } else {
                setUserRole('user');
              }
            }
            // Загружаем lastSeenNewsId с сервера
            if (data.user?.lastSeenNewsId) {
              setLastSeenNewsId(data.user.lastSeenNewsId);
            }
          } else {
            console.warn('⚠️ Failed to fetch user info:', response.status);
            // Fallback to ADMIN_ID check
            if (tgUser.id === ADMIN_ID) {
              setUserRole('moderator');
            }
          }
        } catch (e) {
          console.error('❌ Error fetching user info:', e);
          // Fallback to ADMIN_ID check
          if (tgUser.id === ADMIN_ID) {
            setUserRole('moderator');
          }
        }
      };
      fetchMyUserInfo();
      // Баланс загружается с сервера через API (не localStorage)
      setUserBalance(0);
    } else {
      setUser({ id: 0, firstName: 'Гость', lastName: '', username: 'guest', photoUrl: null });
    }

    // Загружаем данные с сервера вместо localStorage
    const loadDataFromServer = async () => {
      try {
        const headers = { 'x-telegram-init-data': window.Telegram?.WebApp?.initData || '' };

        // Загружаем личные программы
        const programsRes = await fetch(`${API_URL}/programs/my`, { headers });
        if (programsRes.ok) {
          const data = await programsRes.json();
          if (data.success && data.programs) setPrograms(data.programs);
        }

        // Загружаем купленные программы
        const purchasedRes = await fetch(`${API_URL}/purchases`, { headers });
        if (purchasedRes.ok) {
          const data = await purchasedRes.json();
          if (data.success && data.programs) setPurchasedPrograms(data.programs);
        }

        // Загружаем историю тренировок
        const historyRes = await fetch(`${API_URL}/workouts/history`, { headers });
        if (historyRes.ok) {
          const data = await historyRes.json();
          if (data.success && data.history) setWorkoutHistory(data.history);
        }

        // Загружаем рекорды упражнений
        const recordsRes = await fetch(`${API_URL}/workouts/records`, { headers });
        if (recordsRes.ok) {
          const data = await recordsRes.json();
          if (data.success && data.records) setExerciseRecords(data.records);
        }
      } catch (error) {
        console.error('Error loading data from server:', error);
      }
    };

    if (window.Telegram?.WebApp?.initData) {
      loadDataFromServer();
    }

    // seenNewsCount теперь сбрасывается при открытии модального окна

    setMarketPrograms([
      {
        id: 'm1', title: 'Набор массы PRO', author: 'Алексей Тренер', authorId: 123, category: 'Масса', price: 199, rating: 4.8, reviews: 124, isPro: true, exercises: [
          { name: 'Жим лёжа', sets: 4, reps: '8-10', weight: '60' },
          { name: 'Тяга штанги', sets: 4, reps: '8-10', weight: '50' },
          { name: 'Приседания', sets: 4, reps: '10-12', weight: '70' },
        ]
      },
      {
        id: 'm2', title: 'Жиросжигание', author: 'Мария Фит', authorId: 456, category: 'Похудение', price: 99, rating: 4.6, reviews: 89, isPro: false, exercises: [
          { name: 'Бёрпи', sets: 3, reps: '15', weight: '' },
          { name: 'Скакалка', sets: 3, reps: '100', weight: '' },
        ]
      },
      {
        id: 'm3', title: 'Силовая 5x5', author: 'Иван Сила', authorId: 789, category: 'Сила', price: 0, rating: 4.9, reviews: 256, isPro: false, exercises: [
          { name: 'Присед', sets: 5, reps: '5', weight: '100' },
          { name: 'Жим', sets: 5, reps: '5', weight: '80' },
          { name: 'Тяга', sets: 5, reps: '5', weight: '120' },
        ]
      },
    ]);

    setIsLoading(false);
  }, []);

  useEffect(() => {
    if (activeWorkout && !workoutMinimized) {
      timerRef.current = setInterval(() => setWorkoutTimer(prev => prev + 1), 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [activeWorkout, workoutMinimized]);

  const isAdmin = user?.id === ADMIN_ID;
  // Роли: admin > moderator > trainer > user
  const isModerator = userRole === 'moderator' || isAdmin; // Только модераторы и админы
  const isTrainer = userRole === 'trainer'; // Только тренеры (не включает модераторов!)
  const canSeeTrainerPanel = isTrainer || isModerator; // Кто видит панель тренера

  const savePrograms = (p) => { setPrograms(p); }; // Только локально обновляем UI

  const createProgram = () => {
    setEditingProgram({ id: `prog_${Date.now()}`, title: 'Новая программа', exercises: [], createdAt: new Date().toISOString() });
    setShowProgramEditor(true);
  };

  const saveProgramFromEditor = async (prog) => {
    try {
      const headers = {
        'Content-Type': 'application/json',
        'x-telegram-init-data': window.Telegram?.WebApp?.initData || ''
      };

      const exists = programs.find(p => p.id === prog.id);

      // Сохраняем на сервер
      await fetch(`${API_URL}/programs/my`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          id: prog.id,
          title: prog.title,
          exercises: prog.exercises
        })
      });

      // Обновляем локальный state
      if (exists) {
        setPrograms(programs.map(p => p.id === prog.id ? prog : p));
      } else {
        setPrograms([...programs, prog]);
      }
    } catch (error) {
      console.error('Error saving program:', error);
    }
    setShowProgramEditor(false);
    setEditingProgram(null);
  };

  const deleteProgram = async (id) => {
    try {
      const headers = { 'x-telegram-init-data': window.Telegram?.WebApp?.initData || '' };
      await fetch(`${API_URL}/programs/my/${id}`, { method: 'DELETE', headers });
      setPrograms(programs.filter(p => p.id !== id));
    } catch (error) {
      console.error('Error deleting program:', error);
    }
    setShowProgramEditor(false);
    setEditingProgram(null);
  };

  const getExerciseRecord = (exerciseName) => {
    return exerciseRecords[exerciseName.toLowerCase()] || null;
  };

  const updateExerciseRecord = (exerciseName, weight, reps) => {
    const key = exerciseName.toLowerCase();
    const current = exerciseRecords[key];
    const newWeight = parseFloat(weight) || 0;
    const newReps = parseInt(reps) || 0;

    if (!current || newWeight > current.weight || (newWeight === current.weight && newReps > current.reps)) {
      const newRecords = { ...exerciseRecords, [key]: { weight: newWeight, reps: newReps, date: new Date().toISOString() } };
      setExerciseRecords(newRecords);
      // Рекорды сохраняются на сервер при завершении тренировки
      return true;
    }
    return false;
  };

  const startWorkout = (program) => {
    const exerciseSets = {};
    program.exercises?.forEach((ex, i) => {
      const record = getExerciseRecord(ex.name);
      exerciseSets[i] = Array.from({ length: ex.sets || 3 }, () => ({
        prevWeight: record?.weight || ex.weight || '',
        prevReps: record?.reps || ex.reps || '',
        weight: '',
        reps: '',
        completed: false
      }));
    });
    setActiveWorkout({ program, exerciseSets, startTime: Date.now(), exerciseDetails: [] });
    setWorkoutMinimized(false);
    setWorkoutTimer(0);
  };

  const finishWorkout = async () => {
    if (!activeWorkout) return;

    let totalVolume = 0, totalSets = 0;
    const exerciseDetails = [];

    Object.entries(activeWorkout.exerciseSets || {}).forEach(([exIdx, sets]) => {
      const exercise = activeWorkout.program.exercises[exIdx];
      const completedSets = [];

      sets.forEach((s, setIdx) => {
        if (s.completed) {
          totalSets++;
          // Если вес не введен, пробуем взять предыдущий
          const w = parseFloat(s.weight) || parseFloat(s.prevWeight) || 0;
          const r = parseInt(s.reps) || parseInt(s.prevReps) || 0;
          totalVolume += w * r;
          completedSets.push({ set: setIdx + 1, weight: w, reps: r });

          if (exercise?.name) {
            updateExerciseRecord(exercise.name, w, r);
          }
        }
      });

      if (completedSets.length > 0 && exercise) {
        exerciseDetails.push({ name: exercise.name, sets: completedSets });
      }
    });

    const record = {
      id: `wh_${Date.now()}`,
      programTitle: activeWorkout.program.title,
      duration: workoutTimer,
      volume: totalVolume,
      totalSets: totalSets,
      exercises: exerciseDetails,
      date: new Date().toISOString()
    };

    const newHistory = [record, ...workoutHistory];
    setWorkoutHistory(newHistory);

    // Сохраняем тренировку на сервер
    try {
      const headers = {
        'Content-Type': 'application/json',
        'x-telegram-init-data': window.Telegram?.WebApp?.initData || ''
      };
      await fetch(`${API_URL}/workouts/log`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          programId: activeWorkout.program.id,
          workoutTitle: activeWorkout.program.title,
          exercises: exerciseDetails,
          duration: workoutTimer,
          volume: totalVolume,
          records: exerciseRecords,
        })
      });
    } catch (error) {
      console.error('Error saving workout to server:', error);
    }

    setWorkoutSummary({
      duration: workoutTimer,
      volume: totalVolume,
      sets: totalSets,
      title: activeWorkout.program.title
    });
    setActiveWorkout(null);
    setWorkoutMinimized(false);
  };

  const updateWorkoutSet = (exIdx, setIdx, field, value) => {
    const newSets = { ...activeWorkout.exerciseSets };
    newSets[exIdx] = [...newSets[exIdx]];
    newSets[exIdx][setIdx] = { ...newSets[exIdx][setIdx], [field]: value };
    setActiveWorkout({ ...activeWorkout, exerciseSets: newSets });
  };

  const addWorkoutSet = (exIdx) => {
    const newSets = { ...activeWorkout.exerciseSets };
    const last = newSets[exIdx][newSets[exIdx].length - 1];
    newSets[exIdx] = [...newSets[exIdx], { prevWeight: last?.prevWeight || '', prevReps: last?.prevReps || '', weight: '', reps: '', completed: false }];
    setActiveWorkout({ ...activeWorkout, exerciseSets: newSets });
  };

  const updateBalance = (userId, amount) => {
    // Баланс управляется через сервер (CryptoBot API)
    if (userId === user?.id) setUserBalance(prev => prev + amount);
    return userBalance + amount;
  };

  const fetchAppBalance = async () => {
    try {
      const initData = tg?.initData || `user=${encodeURIComponent(JSON.stringify({ id: user?.id || ADMIN_ID, first_name: user?.firstName || 'Admin' }))}`;
      const response = await fetch('https://fitness-backendnew.onrender.com/api/crypto/balance', {
        headers: { 'x-telegram-init-data': initData }
      });
      const data = await response.json();
      const usdt = data.find(c => c.currency_code === 'USDT');
      setAppBalance(usdt ? parseFloat(usdt.available) : 0);
    } catch (e) {
      console.error('Error fetching balance:', e);
    }
  };

  useEffect(() => {
    if (activeTab === 'moderator' && (isAdmin || isModerator)) {
      fetchAppBalance();
    }
  }, [activeTab, isAdmin, isModerator]);

  const API_URL = 'https://fitness-backendnew.onrender.com/api';
  const getInitData = () => tg?.initData || `user=${encodeURIComponent(JSON.stringify({ id: user?.id || ADMIN_ID, first_name: user?.firstName || 'Admin' }))}`;

  // Загрузка новостей с сервера
  const fetchNews = async () => {
    try {
      const response = await fetch(`${API_URL}/content/news`);
      const data = await response.json();
      if (Array.isArray(data)) setNews(data);
    } catch (e) {
      console.error('Error fetching news:', e);
    }
  };

  // Создание новости на сервере
  const createNewsOnServer = async (title, content) => {
    try {
      const response = await fetch(`${API_URL}/content/news`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-telegram-init-data': getInitData() },
        body: JSON.stringify({ title, content }),
      });
      const data = await response.json();
      if (data.success) {
        fetchNews(); // Обновляем список
        return true;
      }
      showToast(data.error || 'Ошибка создания новости', 'error');
      return false;
    } catch (e) {
      console.error('Error creating news:', e);
      return false;
    }
  };

  // Удаление новости на сервере
  const deleteNewsOnServer = async (id) => {
    try {
      const response = await fetch(`${API_URL}/content/news/${id}`, {
        method: 'DELETE',
        headers: { 'x-telegram-init-data': getInitData() },
      });
      if (response.ok) fetchNews();
    } catch (e) {
      console.error('Error deleting news:', e);
    }
  };

  // Загрузка программ с сервера
  const fetchPrograms = async () => {
    try {
      const response = await fetch(`${API_URL}/content/programs`);
      const data = await response.json();
      if (Array.isArray(data)) {
        // Объединяем с хардкодными программами маркета
        setMarketPrograms(prev => {
          const hardcoded = prev.filter(p => p.id.startsWith('m'));
          return [...hardcoded, ...data];
        });
      }
    } catch (e) {
      console.error('Error fetching programs:', e);
    }
  };

  // Создание программы на сервере
  const createProgramOnServer = async (progData) => {
    try {
      const response = await fetch(`${API_URL}/content/programs`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-telegram-init-data': getInitData() },
        body: JSON.stringify(progData),
      });
      const data = await response.json();
      if (data.success) {
        fetchPrograms();
        setPrograms(prev => [...prev, data.program]);
        return true;
      }
      showToast(data.error || 'Ошибка создания программы', 'error');
      return false;
    } catch (e) {
      console.error('Error creating program:', e);
      return false;
    }
  };

  // Удаление программы на сервере
  const deleteProgramOnServer = async (id) => {
    try {
      const response = await fetch(`${API_URL}/content/programs/${id}`, {
        method: 'DELETE',
        headers: { 'x-telegram-init-data': getInitData() },
      });
      if (response.ok) {
        fetchPrograms();
        setPrograms(prev => prev.filter(p => p.id !== id));
      }
    } catch (e) {
      console.error('Error deleting program:', e);
    }
  };

  // Загружаем новости и программы при старте и обновляем каждые 30 секунд
  useEffect(() => {
    fetchNews();
    fetchPrograms();

    // Загружаем заявки на тренера (для модераторов)
    if (isModerator || user?.id === ADMIN_ID) {
      fetchTrainerRequests();
      fetchSupportMessages();
      fetchRoles();
    } else if (user?.id) {
      fetchMySupportMessages();
    }

    // Функция обновления роли пользователя с сервера
    const refreshUserRole = async () => {
      if (!user?.id) return;
      try {
        const response = await fetch(`${API_URL}/user/me`, {
          headers: { 'x-telegram-init-data': getInitData() },
        });
        if (response.ok) {
          const data = await response.json();
          if (data.user?.role) {
            const serverRole = data.user.role.toLowerCase();
            if (serverRole === 'admin' || serverRole === 'moderator') {
              setUserRole('moderator');
            } else if (serverRole === 'trainer') {
              setUserRole('trainer');
            } else {
              setUserRole('user');
            }
          }
        }
      } catch (e) {
        console.error('Error refreshing role:', e);
      }
    };

    // Функция загрузки глобальной настройки новогодней темы
    const fetchNewYearTheme = async () => {
      try {
        const response = await fetch(`${API_URL}/settings/new-year-theme`);
        if (response.ok) {
          const data = await response.json();
          setShowNewYearTheme(data.enabled);
        }
      } catch (e) {
        console.error('Error fetching new year theme:', e);
      }
    };

    // Загружаем настройку при старте
    fetchNewYearTheme();

    // Автоматическое обновление каждые 30 секунд
    const newsInterval = setInterval(() => {
      fetchNews();
      refreshUserRole(); // Обновляем роль пользователя
      fetchNewYearTheme(); // Синхронизируем глобальную тему
      if (isModerator || user?.id === ADMIN_ID) {
        fetchTrainerRequests();
        fetchSupportMessages();
        fetchRoles();
      }
    }, 30000);

    return () => clearInterval(newsInterval);
  }, [isModerator, user?.id]);

  const addBalanceTransaction = (type, amount, desc) => {
    const tx = { id: `tx_${Date.now()}`, type, amount, description: desc, date: new Date().toISOString(), userId: user?.id };
    const newHist = [tx, ...balanceHistory];
    setBalanceHistory(newHist);
    // История баланса теперь только в памяти (не критично для синхронизации)
  };

  const depositStars = async () => {
    // Пополнение через CryptoBot
    const amount = prompt('Сколько USDT добавить на баланс?\n\n(Минимум 1 USDT)');
    if (!amount || isNaN(amount) || parseFloat(amount) < 1) {
      if (amount) alert('Минимальная сумма: 1 USDT');
      return;
    }

    try {
      const API_URL = 'https://fitness-backendnew.onrender.com/api';
      // Используем реальный initData или создаём mock для тестирования
      let initData = tg?.initData || '';
      if (!initData && user?.id) {
        // Mock initData для тестирования вне Telegram
        initData = 'user=' + encodeURIComponent(JSON.stringify({ id: user.id, first_name: user.firstName || 'Test' }));
      }

      const response = await fetch(`${API_URL}/crypto/deposit`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-telegram-init-data': initData,
        },
        body: JSON.stringify({ amount: parseFloat(amount) }),
      });

      const data = await response.json();

      if (data.payUrl) {
        // Открываем ссылку на оплату в CryptoBot
        if (tg?.openTelegramLink) {
          tg.openTelegramLink(data.payUrl);
        } else {
          window.open(data.payUrl, '_blank');
        }
        alert(`💳 Откройте CryptoBot для оплаты ${amount} USDT\n\nПосле оплаты баланс обновится автоматически.`);
      } else {
        alert('❌ Ошибка создания платежа: ' + (data.error || 'Неизвестная ошибка'));
      }
    } catch (error) {
      console.error('Deposit error:', error);
      alert('❌ Ошибка подключения к серверу');
    }
  };

  const withdrawStars = async () => {
    // Вывод через CryptoBot (для тренеров и модераторов)
    if (!canSeeTrainerPanel && user?.id !== ADMIN_ID) {
      alert('❌ Вывод доступен только тренерам');
      return;
    }

    const amount = prompt(`Сколько USDT вывести?\n\nДоступно: ${userBalance} ⭐\n\n(1 ⭐ = 1 USDT)\n\nКомиссия: ${withdrawalFee}%`);
    if (!amount || isNaN(amount) || parseFloat(amount) <= 0) {
      return;
    }

    if (parseFloat(amount) > userBalance) {
      alert('❌ Недостаточно средств!');
      return;
    }

    // Создаём заявку на вывод (требует одобрения модератора)
    const newRequest = {
      id: `wr_${Date.now()}`,
      userId: user.id,
      userName: `${user.firstName} ${user.lastName || ''}`.trim(),
      username: user.username,
      amount: parseFloat(amount),
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    const updated = [...withdrawalRequests, newRequest];
    setWithdrawalRequests(updated);
    // Заявки на вывод хранятся локально (текущая сессия)

    // Резервируем средства (списываем с баланса)
    updateBalance(user.id, -parseFloat(amount));
    addBalanceTransaction('withdraw_pending', parseFloat(amount), 'Заявка на вывод (ожидает одобрения)');

    alert(`📋 Заявка на вывод ${amount} USDT создана!\n\nОжидайте одобрения модератором.\n\nКомиссия: ${(parseFloat(amount) * withdrawalFee / 100).toFixed(2)} USDT\nК получению: ${(parseFloat(amount) * (1 - withdrawalFee / 100)).toFixed(2)} USDT`);
  };

  const purchaseProgram = (prog) => {
    if (prog.price === 0) {
      const newPurchased = [...purchasedPrograms, { ...prog, purchasedAt: new Date().toISOString() }];
      setPurchasedPrograms(newPurchased);
      // Покупки сохраняются на сервере через API
      alert('Программа добавлена!');
      return;
    }

    if (userBalance < prog.price) {
      alert(`Недостаточно ⭐ Stars!\nНужно: ${prog.price}\nУ вас: ${userBalance}\n\nПополните баланс.`);
      return;
    }

    updateBalance(user.id, -prog.price);
    addBalanceTransaction('purchase', prog.price, `Покупка: ${prog.title}`);
    updateBalance(prog.authorId, Math.floor(prog.price * 0.9));

    const newPurchased = [...purchasedPrograms, { ...prog, purchasedAt: new Date().toISOString() }];
    setPurchasedPrograms(newPurchased);
    // Покупки сохраняются на сервере через API

    alert(`✅ Программа "${prog.title}" куплена за ${prog.price} ⭐`);
  };

  // Отправить  // Заявка на тренера
  const requestTrainerRole = async () => {
    try {
      const response = await fetch(`${API_URL}/trainer-request`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-telegram-init-data': getInitData() },
      });
      const data = await response.json();
      if (response.ok) {
        showToast('✅ Заявка на тренера отправлена!', 'success');
      } else {
        showToast(data.error || 'Ошибка отправки заявки', 'error');
      }
    } catch (e) {
      console.error(e);
      showToast('Ошибка сети', 'error');
    }
  };

  // Одобрение/отклонение заявки (админ/модер)
  const handleTrainerRequest = async (requestId, action) => {
    try {
      const response = await fetch(`${API_URL}/admin/trainer-request`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-telegram-init-data': getInitData() },
        body: JSON.stringify({ requestId, action }),
      });
      const data = await response.json();
      if (response.ok) {
        showToast(`✅ Заявка ${action === 'approve' ? 'одобрена' : 'отклонена'}`, 'success');
        fetchTrainerRequests(); // Обновить список
      } else {
        showToast(data.error || 'Ошибка', 'error');
      }
    } catch (e) {
      console.error(e);
      showToast('Ошибка сети', 'error');
    }
  };

  // Отклонить заявку на тренера (API)
  const rejectTrainer = async (reqId) => {
    try {
      const response = await fetch(`${API_URL}/content/trainer-requests/${reqId}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-telegram-init-data': getInitData() },
        body: JSON.stringify({ reason: '' }),
      });
      if (response.ok) {
        fetchTrainerRequests();
      }
    } catch (e) {
      console.error('Error rejecting trainer:', e);
    }
  };

  // Загрузить заявки на тренера (API)
  const fetchTrainerRequests = async () => {
    try {
      const response = await fetch(`${API_URL}/content/trainer-requests`, {
        headers: { 'x-telegram-init-data': getInitData() },
      });
      if (response.ok) {
        const data = await response.json();
        if (Array.isArray(data)) {
          setTrainerRequests(data.map(r => ({
            id: r.id,
            userId: r.telegram_id,
            username: r.username,
            firstName: r.first_name,
            lastName: r.last_name,
            createdAt: r.created_at,
          })));
        }
      }
    } catch (e) {
      console.error('Error fetching trainer requests:', e);
    }
  };

  const [rolesList, setRolesList] = useState([]);

  // Загрузить список ролей (API)
  const fetchRoles = async () => {
    console.log('🔍 fetchRoles called, user?.id:', user?.id, 'ADMIN_ID:', ADMIN_ID, 'isAdmin:', user?.id === ADMIN_ID);
    try {
      // Только админ может видеть полный список ролей
      if (user?.id !== ADMIN_ID) {
        console.log('⚠️ fetchRoles: Not admin, skipping');
        return;
      }

      console.log('✅ fetchRoles: Fetching from API...');
      const response = await fetch(`${API_URL}/content/roles`, {
        headers: { 'x-telegram-init-data': getInitData() },
      });
      console.log('📡 fetchRoles response status:', response.status);
      if (response.ok) {
        const data = await response.json();
        console.log('✅ fetchRoles data:', data);
        setRolesList(data);
      } else {
        const errorText = await response.text();
        console.error('❌ fetchRoles error:', response.status, errorText);
      }
    } catch (e) {
      console.error('❌ Error fetching roles:', e);
    }
  };

  // Состояние для уведомлений
  const [toast, setToast] = useState(null);
  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  // Назначить роль (добавляет, не заменяет)
  const assignRole = async (telegramId, role) => {
    if (!telegramId) {
      showToast('Введите Telegram ID', 'error');
      return;
    }

    try {
      const response = await fetch(`${API_URL}/content/roles/assign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-telegram-init-data': getInitData() },
        body: JSON.stringify({ telegramId, role }),
      });

      const data = await response.json();

      if (response.ok) {
        showToast(data.message, 'success');
        // Небольшая задержка чтобы база успела обновиться
        await new Promise(r => setTimeout(r, 500));
        await fetchRoles(); // Обновляем список тренеров
        if (isAdmin) fetchAdminData(); // Обновляем админку
      } else {
        showToast(data.error || 'Ошибка назначения', 'error');
      }
    } catch (e) {
      console.error(e);
      showToast('Ошибка сети', 'error');
    }
  };

  // Снять конкретную роль
  const removeRoleFromUser = async (telegramId, role) => {
    try {
      const response = await fetch(`${API_URL}/content/roles/remove`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-telegram-init-data': getInitData() },
        body: JSON.stringify({ telegramId, role }),
      });

      const data = await response.json();

      if (response.ok) {
        showToast(data.message, 'success');
        fetchRoles(); // Обновляем список без перезагрузки
      } else {
        showToast(data.error || 'Ошибка снятия роли', 'error');
      }
    } catch (e) {
      console.error(e);
      showToast('Ошибка сети', 'error');
    }
  };

  // Обёртки для обратной совместимости
  const removeTrainerRole = (userId) => removeRoleFromUser(userId, 'TRAINER');
  const removeModeratorRole = (userId) => removeRoleFromUser(userId, 'MODERATOR');
  const setUserAsModerator = (userId) => assignRole(userId, 'MODERATOR');
  const setManualTrainer = (userId) => assignRole(userId, 'TRAINER');

  // Сохранение профиля
  const saveProfile = async () => {
    if (profileDisplayName.trim().length < 2) {
      showToast('Имя должно содержать минимум 2 символа', 'error');
      return;
    }

    setProfileSaving(true);
    try {
      const response = await fetch(`${API_URL}/user/update`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-telegram-init-data': getInitData() },
        body: JSON.stringify({
          displayName: profileDisplayName.trim(),
          avatarUrl: profileAvatarUrl,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        showToast('Профиль сохранён!', 'success');
        // Обновляем локальное состояние
        setUser(prev => ({
          ...prev,
          displayName: data.user?.displayName || profileDisplayName,
          avatarUrl: data.user?.avatarUrl || profileAvatarUrl,
        }));
        setShowProfileSettings(false);
      } else {
        showToast(data.error || 'Ошибка сохранения', 'error');
      }
    } catch (e) {
      console.error(e);
      showToast('Ошибка сети', 'error');
    } finally {
      setProfileSaving(false);
    }
  };

  // Обработка загрузки аватара
  const handleAvatarUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Проверка типа
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      showToast('Только JPG, PNG или WEBP', 'error');
      return;
    }

    // Проверка размера (5MB)
    if (file.size > 5 * 1024 * 1024) {
      showToast('Файл слишком большой (макс 5MB)', 'error');
      return;
    }

    // Конвертируем в Base64
    const reader = new FileReader();
    reader.onloadend = () => {
      setProfileAvatarUrl(reader.result);
    };
    reader.readAsDataURL(file);
  };

  // Сброс аккаунта пользователя (API)
  const resetUserAccount = async (userId) => {
    console.log('🔄 resetUserAccount called with userId:', userId);
    try {
      const response = await fetch(`${API_URL}/content/reset-account/${userId}`, {
        method: 'POST',
        headers: { 'x-telegram-init-data': getInitData() },
      });
      console.log('📡 resetUserAccount response status:', response.status);
      const data = await response.json();
      console.log('📦 resetUserAccount response data:', data);
      if (data.success) {
        showToast(`✅ Аккаунт ${userId} сброшен!`, 'success');
      } else {
        showToast(`❌ Ошибка: ${data.error || 'Неизвестная ошибка'}`, 'error');
      }
    } catch (e) {
      console.error('❌ Error resetting account:', e);
      showToast('❌ Ошибка подключения к серверу', 'error');
    }
  };

  // Отправить сообщение в поддержку (API)
  const sendSupportMessage = async () => {
    if (!newMessage.trim()) return;
    try {
      const response = await fetch(`${API_URL}/content/support/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-telegram-init-data': getInitData() },
        body: JSON.stringify({ message: newMessage.trim() }),
      });
      const data = await response.json();
      if (data.success) {
        setSupportMessages(prev => [...prev, {
          id: data.message.id,
          text: data.message.message,
          from: data.message.from_user_id,
          fromName: data.message.from_user_name,
          to: 'support',
          date: data.message.created_at,
        }]);
        setNewMessage('');
      }
    } catch (e) {
      console.error('Error sending support message:', e);
    }
  };

  // Ответить пользователю (API)
  const sendModeratorReply = async (toUserId, text) => {
    if (!text.trim()) return;
    try {
      const response = await fetch(`${API_URL}/content/support/reply/${toUserId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-telegram-init-data': getInitData() },
        body: JSON.stringify({ message: text.trim() }),
      });
      const data = await response.json();
      if (data.success) {
        setSupportMessages(prev => [...prev, {
          id: data.message.id,
          text: data.message.message,
          from: 'support',
          fromName: 'Поддержка',
          to: toUserId,
          date: data.message.created_at,
        }]);
      }
    } catch (e) {
      console.error('Error sending moderator reply:', e);
    }
  };

  // Получить сообщения пользователя
  const getUserMessages = (userId) => {
    return supportMessages.filter(m => m.from == userId || m.to == userId).sort((a, b) => new Date(a.date) - new Date(b.date));
  };

  // Получить уникальных пользователей чата
  const getUniqueChatUsers = () => {
    const users = {};
    supportMessages.forEach(m => {
      if (m.from !== 'support' && m.from && m.from !== 0) {
        users[m.from] = { id: m.from, name: m.fromName, username: m.fromUsername };
      }
    });
    return Object.values(users);
  };

  // Загрузить сообщения поддержки (API)
  const fetchSupportMessages = async () => {
    try {
      const response = await fetch(`${API_URL}/content/support/messages`, {
        headers: { 'x-telegram-init-data': getInitData() },
      });
      if (response.ok) {
        const data = await response.json();
        if (Array.isArray(data)) {
          setSupportMessages(data.map(m => ({
            id: m.id,
            text: m.message,
            from: m.from_user_id === 0 ? 'support' : m.from_user_id,
            fromName: m.from_user_name,
            fromUsername: m.from_username,
            to: m.to_user_id,
            date: m.created_at,
          })));
        }
      }
    } catch (e) {
      console.error('Error fetching support messages:', e);
    }
  };

  // Загрузить мои сообщения (для обычных пользователей)
  const fetchMySupportMessages = async () => {
    if (!user?.id) return;
    try {
      const response = await fetch(`${API_URL}/content/support/messages/${user.id}`, {
        headers: { 'x-telegram-init-data': getInitData() },
      });
      if (response.ok) {
        const data = await response.json();
        if (Array.isArray(data)) {
          setSupportMessages(data.map(m => ({
            id: m.id,
            text: m.message,
            from: m.from_user_id === 0 ? 'support' : m.from_user_id,
            fromName: m.from_user_name,
            fromUsername: m.from_username,
            to: m.to_user_id,
            date: m.created_at,
          })));
        }
      }
    } catch (e) {
      console.error('Error fetching my support messages:', e);
    }
  };

  const filteredMarket = marketPrograms.filter(p => {
    if (marketFilter !== 'Все' && p.category !== marketFilter) return false;
    if (searchQuery && !p.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const formatTime = (sec) => `${Math.floor(sec / 60)}:${(sec % 60).toString().padStart(2, '0')}`;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0d0d0d] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  // === ТРЕБУЕТСЯ РЕГИСТРАЦИЯ ЧЕРЕЗ БОТА ===
  if (needsRegistration) {
    return (
      <div className="min-h-screen bg-[#0d0d0d] flex items-center justify-center p-6">
        <div className="text-center max-w-sm">
          <div className="w-24 h-24 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <span className="text-5xl">🤖</span>
          </div>
          <h1 className="text-2xl font-bold text-white mb-4">Требуется регистрация</h1>
          <p className="text-gray-400 mb-6">
            Для использования приложения сначала напишите <span className="text-blue-400 font-bold">/start</span> боту
          </p>
          <button
            onClick={() => {
              // Открыть бота в Telegram
              if (window.Telegram?.WebApp) {
                window.Telegram.WebApp.close();
              }
            }}
            className="w-full bg-blue-500 text-white py-4 rounded-xl font-medium text-lg hover:bg-blue-600 transition-colors"
          >
            Перейти к боту
          </button>
          <button
            onClick={() => window.location.reload()}
            className="w-full bg-[#1a1a1a] text-gray-400 py-3 rounded-xl mt-3 hover:bg-[#222] transition-colors"
          >
            Я уже зарегистрирован — обновить
          </button>
        </div>
      </div>
    );
  }

  // === РЕДАКТОР ПРОГРАММЫ ===
  if (showProgramEditor && editingProgram) {
    return (
      <div className="min-h-screen bg-[#0d0d0d] text-white">
        <div className="sticky top-0 bg-[#0d0d0d] border-b border-white/10 p-4 flex items-center justify-between z-10">
          <button onClick={() => { setShowProgramEditor(false); setEditingProgram(null); }} className="flex items-center gap-2 text-gray-400">
            <ChevronLeft className="w-5 h-5" /><span>Назад</span>
          </button>
          <button onClick={() => saveProgramFromEditor(editingProgram)} className="bg-blue-500 text-white px-4 py-2 rounded-lg font-medium flex items-center gap-2">
            <Save className="w-4 h-4" />Сохранить
          </button>
        </div>
        <div className="p-4">
          <input type="text" value={editingProgram.title} onChange={(e) => setEditingProgram({ ...editingProgram, title: e.target.value })}
            className="w-full bg-[#1a1a1a] text-xl font-bold p-4 rounded-xl mb-4 border border-white/10 focus:border-blue-500 outline-none" placeholder="Название программы" />

          <h3 className="font-semibold mb-3 text-gray-400">УПРАЖНЕНИЯ</h3>

          {editingProgram.exercises?.map((ex, i) => (
            <div key={i} className="bg-[#1a1a1a] rounded-xl p-4 mb-3 border border-white/5">
              <div className="flex items-center justify-between mb-3">
                {ex.isCustom ? (
                  <input type="text" value={ex.name} onChange={(e) => {
                    const newExercises = editingProgram.exercises.map((item, idx) =>
                      idx === i ? { ...item, name: e.target.value } : item
                    );
                    setEditingProgram({ ...editingProgram, exercises: newExercises });
                  }} className="bg-[#0d0d0d] font-semibold text-blue-400 flex-1 outline-none text-lg px-3 py-2 rounded-lg border border-white/10" placeholder="Введите название упражнения" />
                ) : (
                  <select
                    value={ex.name}
                    onChange={(e) => {
                      const newExercises = editingProgram.exercises.map((item, idx) => {
                        if (idx !== i) return item;
                        if (e.target.value === '__custom__') {
                          return { ...item, name: '', isCustom: true };
                        }
                        return { ...item, name: e.target.value };
                      });
                      setEditingProgram({ ...editingProgram, exercises: newExercises });
                    }}
                    className="bg-[#0d0d0d] font-semibold text-blue-400 flex-1 outline-none text-lg px-3 py-2 rounded-lg border border-white/10"
                  >
                    <option value="">Выберите упражнение</option>
                    {Object.entries(EXERCISE_LIST).map(([category, exercises]) => (
                      <optgroup key={category} label={category}>
                        {exercises.map(name => (
                          <option key={name} value={name}>{name}</option>
                        ))}
                      </optgroup>
                    ))}
                    <option value="__custom__">📝 Другое (ввести вручную)</option>
                  </select>
                )}
                <button onClick={() => {
                  const newEx = editingProgram.exercises.filter((_, idx) => idx !== i);
                  setEditingProgram({ ...editingProgram, exercises: newEx });
                }} className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg ml-2"><Trash2 className="w-4 h-4" /></button>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-gray-500 block mb-1">Подходы</label>
                  <input type="number" value={ex.sets} onChange={(e) => {
                    const newExercises = editingProgram.exercises.map((item, idx) =>
                      idx === i ? { ...item, sets: parseInt(e.target.value) || 0 } : item
                    );
                    setEditingProgram({ ...editingProgram, exercises: newExercises });
                  }} className="w-full bg-[#0d0d0d] p-3 rounded-lg text-center outline-none border border-white/10 focus:border-blue-500" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 block mb-1">Повторы</label>
                  <input type="text" value={ex.reps} onChange={(e) => {
                    const newExercises = editingProgram.exercises.map((item, idx) =>
                      idx === i ? { ...item, reps: e.target.value } : item
                    );
                    setEditingProgram({ ...editingProgram, exercises: newExercises });
                  }} className="w-full bg-[#0d0d0d] p-3 rounded-lg text-center outline-none border border-white/10 focus:border-blue-500" placeholder="10" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 block mb-1">Вес (кг)</label>
                  <input type="text" value={ex.weight || ''} onChange={(e) => {
                    const newExercises = editingProgram.exercises.map((item, idx) =>
                      idx === i ? { ...item, weight: e.target.value } : item
                    );
                    setEditingProgram({ ...editingProgram, exercises: newExercises });
                  }} className="w-full bg-[#0d0d0d] p-3 rounded-lg text-center outline-none border border-white/10 focus:border-blue-500" placeholder="—" />
                </div>
              </div>
            </div>
          ))}

          <button onClick={() => setEditingProgram({ ...editingProgram, exercises: [...(editingProgram.exercises || []), { name: '', sets: 3, reps: '10', weight: '', isCustom: false }] })}
            className="w-full bg-[#1a1a1a] rounded-xl p-4 flex items-center justify-center gap-2 border border-dashed border-blue-500/50 hover:bg-blue-500/10 transition-colors">
            <Plus className="w-5 h-5 text-blue-500" /><span className="text-blue-500 font-medium">Добавить упражнение</span>
          </button>

          {programs.find(p => p.id === editingProgram.id) && (
            <button onClick={() => deleteProgram(editingProgram.id)} className="w-full bg-red-500/10 text-red-500 rounded-xl p-4 mt-4 flex items-center justify-center gap-2 border border-red-500/30">
              <Trash2 className="w-5 h-5" />Удалить программу
            </button>
          )}
        </div>
      </div>
    );
  }

  // === ПРОСМОТР ПРОШЛОЙ ТРЕНИРОВКИ ===
  if (viewingWorkout) {
    return (
      <div className="min-h-screen bg-[#0d0d0d] text-white">
        <div className="sticky top-0 bg-[#0d0d0d] border-b border-white/10 p-4 flex items-center justify-between z-10">
          <button onClick={() => setViewingWorkout(null)} className="flex items-center gap-2 text-gray-400">
            <ChevronLeft className="w-5 h-5" /><span>Назад</span>
          </button>
          <span className="text-gray-500">{new Date(viewingWorkout.date).toLocaleDateString('ru-RU')}</span>
        </div>

        <div className="p-4">
          <h1 className="text-2xl font-bold mb-2">{viewingWorkout.programTitle}</h1>

          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="bg-[#1a1a1a] rounded-xl p-3 text-center">
              <Timer className="w-5 h-5 text-blue-500 mx-auto mb-1" />
              <div className="font-bold">{formatTime(viewingWorkout.duration)}</div>
              <div className="text-xs text-gray-500">Время</div>
            </div>
            <div className="bg-[#1a1a1a] rounded-xl p-3 text-center">
              <Dumbbell className="w-5 h-5 text-green-500 mx-auto mb-1" />
              <div className="font-bold">{Math.round(viewingWorkout.volume)} кг</div>
              <div className="text-xs text-gray-500">Объём</div>
            </div>
            <div className="bg-[#1a1a1a] rounded-xl p-3 text-center">
              <Check className="w-5 h-5 text-yellow-500 mx-auto mb-1" />
              <div className="font-bold">{viewingWorkout.totalSets}</div>
              <div className="text-xs text-gray-500">Подходов</div>
            </div>
          </div>

          <h3 className="font-semibold text-gray-400 mb-3">УПРАЖНЕНИЯ</h3>

          {viewingWorkout.exercises?.map((ex, i) => (
            <div key={i} className="bg-[#1a1a1a] rounded-xl p-4 mb-3">
              <h4 className="font-semibold text-blue-400 mb-3">{ex.name}</h4>
              <div className="space-y-2">
                {ex.sets?.map((s, j) => (
                  <div key={j} className="flex items-center justify-between bg-[#0d0d0d] rounded-lg p-3">
                    <span className="text-gray-500">Сет {s.set}</span>
                    <span className="font-medium">{s.weight} кг × {s.reps}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // === АКТИВНАЯ ТРЕНИРОВКА ===
  if (activeWorkout && !workoutMinimized) {
    const { program, exerciseSets } = activeWorkout;
    let totalVolume = 0, totalSets = 0;
    Object.values(exerciseSets || {}).forEach(sets => {
      sets.forEach(s => {
        if (s.completed) {
          totalSets++;
          totalVolume += (parseFloat(s.weight) || parseFloat(s.prevWeight) || 0) * (parseInt(s.reps) || parseInt(s.prevReps) || 0);
        }
      });
    });

    return (
      <div className="min-h-screen bg-[#0d0d0d] text-white pb-4">
        <div className="sticky top-0 bg-[#0d0d0d]/95 backdrop-blur border-b border-white/10 p-3 z-10">
          <div className="flex items-center justify-between">
            <button onClick={() => setWorkoutMinimized(true)} className="flex items-center gap-2 text-gray-400 hover:text-white">
              <Minimize2 className="w-5 h-5" /><span>Свернуть</span>
            </button>
            <div className="bg-blue-500/20 text-blue-400 px-4 py-2 rounded-full font-mono font-bold text-lg">
              {formatTime(workoutTimer)}
            </div>
            <button onClick={finishWorkout} className="bg-green-500 text-white px-4 py-2 rounded-lg font-medium">
              Завершить
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 p-4 border-b border-white/10">
          <div className="bg-[#1a1a1a] rounded-xl p-3 text-center">
            <div className="text-blue-400 font-bold text-xl">{formatTime(workoutTimer)}</div>
            <div className="text-xs text-gray-500">Время</div>
          </div>
          <div className="bg-[#1a1a1a] rounded-xl p-3 text-center">
            <div className="font-bold text-xl">{Math.round(totalVolume)}</div>
            <div className="text-xs text-gray-500">Объём (кг)</div>
          </div>
          <div className="bg-[#1a1a1a] rounded-xl p-3 text-center">
            <div className="font-bold text-xl">{totalSets}</div>
            <div className="text-xs text-gray-500">Подходов</div>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {program.exercises?.map((ex, exIdx) => {
            const record = getExerciseRecord(ex.name);
            return (
              <div key={exIdx} className="bg-[#1a1a1a] rounded-2xl overflow-hidden border border-white/5">
                <div className="flex items-center justify-between p-4 border-b border-white/10">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
                      <Dumbbell className="w-6 h-6 text-blue-400" />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg text-blue-400">{ex.name || 'Упражнение'}</h3>
                      {record && (
                        <div className="flex items-center gap-1 text-xs text-yellow-500">
                          <Trophy className="w-3 h-3" />
                          <span>Рекорд: {record.weight}кг × {record.reps}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="px-4">
                  <div className="grid grid-cols-12 gap-2 py-3 text-xs text-gray-500 font-medium border-b border-white/5">
                    <div className="col-span-2">СЕТ</div>
                    <div className="col-span-3 text-center">ПРЕД.</div>
                    <div className="col-span-3 text-center">КГ</div>
                    <div className="col-span-2 text-center">ПОВТ</div>
                    <div className="col-span-2 text-center">✓</div>
                  </div>

                  {exerciseSets[exIdx]?.map((set, setIdx) => {
                    const isNewWeightRecord = set.completed && set.weight && record && parseFloat(set.weight) > record.weight;
                    const isNewRepsRecord = set.completed && set.reps && record && parseFloat(set.weight) >= record.weight && parseInt(set.reps) > record.reps;
                    const isNewRecord = isNewWeightRecord || isNewRepsRecord;
                    return (
                      <div key={setIdx} className={`grid grid-cols-12 gap-2 py-3 items-center border-b border-white/5 ${set.completed ? isNewRecord ? 'bg-yellow-500/10' : 'bg-green-500/10' : ''}`}>
                        <div className="col-span-2 font-bold text-lg">{setIdx + 1}</div>
                        <div className="col-span-3 text-center text-gray-500 text-sm">
                          {set.prevWeight ? `${set.prevWeight}×${set.prevReps}` : '—'}
                        </div>
                        <div className="col-span-3">
                          <input type="number" value={set.weight} onChange={(e) => updateWorkoutSet(exIdx, setIdx, 'weight', e.target.value)}
                            placeholder={set.prevWeight || '0'}
                            className="w-full bg-[#0d0d0d] text-center py-2 rounded-lg border border-white/10 outline-none focus:border-blue-500 font-medium" />
                        </div>
                        <div className="col-span-2">
                          <input type="number" value={set.reps} onChange={(e) => updateWorkoutSet(exIdx, setIdx, 'reps', e.target.value)}
                            placeholder={set.prevReps || '0'}
                            className="w-full bg-[#0d0d0d] text-center py-2 rounded-lg border border-white/10 outline-none focus:border-blue-500 font-medium" />
                        </div>
                        <div className="col-span-2 flex justify-center">
                          <button onClick={() => updateWorkoutSet(exIdx, setIdx, 'completed', !set.completed)}
                            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${set.completed ? isNewRecord ? 'bg-yellow-500 text-black scale-110' : 'bg-green-500 text-white scale-110' : 'bg-[#0d0d0d] border border-white/20 hover:border-green-500'}`}>
                            {set.completed && <Check className="w-5 h-5" />}
                          </button>
                        </div>
                        {isNewRecord && (
                          <div className="col-span-12 flex items-center gap-1 text-yellow-500 text-xs mt-1">
                            <Award className="w-3 h-3" />
                            <span>Новый рекорд!</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                <button onClick={() => addWorkoutSet(exIdx)} className="w-full py-3 text-blue-400 hover:bg-blue-500/10 flex items-center justify-center gap-2 transition-colors">
                  <Plus className="w-4 h-4" />Добавить сет
                </button>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // === MAIN UI ===
  return (
    <div className="min-h-screen bg-[#0d0d0d] text-white pb-24">


      {/* Новогодние снежинки */}
      {showNewYearTheme && <Snowflakes />}

      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        onConfirm={confirmModal.onConfirm}
        onCancel={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
        confirmText={confirmModal.confirmText}
        isDanger={confirmModal.isDanger}
      />

      {/* Toast уведомления */}
      {toast && (
        <div className={`fixed top-4 left-1/2 -translate-x-1/2 z-[200] px-4 py-3 rounded-lg shadow-lg transition-all ${toast.type === 'error' ? 'bg-red-500' : 'bg-green-500'
          } text-white font-medium text-sm`}>
          {toast.message}
        </div>
      )}

      {/* Свёрнутая тренировка */}
      {activeWorkout && workoutMinimized && (
        <div className="fixed top-0 left-0 right-0 bg-gradient-to-r from-blue-600 to-blue-500 p-3 z-50 shadow-lg" onClick={() => setWorkoutMinimized(false)}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center animate-pulse">
                <Play className="w-5 h-5" />
              </div>
              <div>
                <p className="font-semibold">{activeWorkout.program.title}</p>
                <p className="text-sm text-white/70">Тренировка активна</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-mono font-bold text-lg">{formatTime(workoutTimer)}</span>
              <Maximize2 className="w-5 h-5" />
            </div>
          </div>
        </div>
      )}

      {/* ГЛАВНАЯ */}
      {activeTab === 'home' && (
        <div className={`p-4 ${activeWorkout && workoutMinimized ? 'pt-20' : ''}`}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold">Привет, {user?.firstName || 'Атлет'}! 💪</h1>
              <p className="text-gray-500">Готов к тренировке?</p>
            </div>
            <div className="flex items-center gap-3">
              {/* Колокольчик уведомлений */}
              <button
                onClick={async () => {
                  setShowNotificationsModal(true);
                  // Отмечаем новости как прочитанные на сервере
                  if (news.length > 0) {
                    const latestNewsId = news[0]?.id;
                    if (latestNewsId && latestNewsId !== lastSeenNewsId) {
                      setLastSeenNewsId(latestNewsId);
                      try {
                        await fetch(`${API_URL}/user/seen-news`, {
                          method: 'POST',
                          headers: {
                            'Content-Type': 'application/json',
                            'x-telegram-init-data': getInitData(),
                          },
                          body: JSON.stringify({ newsId: latestNewsId }),
                        });
                      } catch (e) {
                        console.error('Error marking news as seen:', e);
                      }
                    }
                  }
                }}
                className="relative p-2 rounded-full bg-[#1a1a1a] hover:bg-[#222] transition-colors"
              >
                <Bell className="w-5 h-5 text-gray-400" />
                {/* Красная точка если есть новые новости которые пользователь ещё не видел */}
                {news.length > 0 && news[0]?.id !== lastSeenNewsId && (
                  <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                )}
              </button>
              <div className="flex items-center gap-2 bg-yellow-500/20 px-3 py-2 rounded-full">
                <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                <span className="font-bold text-yellow-500">{userBalance}</span>
              </div>
            </div>
          </div>

          {workoutHistory.length > 0 && (
            <div className="bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-2xl p-4 mb-6 border border-blue-500/20">
              <h3 className="font-semibold mb-3 flex items-center gap-2"><TrendingUp className="w-5 h-5 text-blue-400" />Статистика</h3>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-blue-400">{workoutHistory.length}</div>
                  <div className="text-xs text-gray-400">Тренировок</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-400">{Math.round(workoutHistory.reduce((a, w) => a + (w.volume || 0), 0) / 1000)}т</div>
                  <div className="text-xs text-gray-400">Объём</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-400">{Math.round(workoutHistory.reduce((a, w) => a + (w.duration || 0), 0) / 60)}м</div>
                  <div className="text-xs text-gray-500">Время</div>
                </div>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Мои программы</h2>
            <button onClick={createProgram} className="bg-blue-500 text-white p-2 rounded-xl"><Plus className="w-5 h-5" /></button>
          </div>

          {programs.length === 0 && purchasedPrograms.length === 0 ? (
            <div className="bg-[#1a1a1a] rounded-2xl p-8 text-center mb-6 border border-white/5">
              <Dumbbell className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-500 mb-4">У вас пока нет программ</p>
              <button onClick={createProgram} className="bg-blue-500 text-white px-6 py-3 rounded-xl font-medium">Создать программу</button>
            </div>
          ) : (
            <div className="space-y-3 mb-6">
              {[...programs, ...purchasedPrograms].map(prog => (
                <div key={prog.id} className="bg-[#1a1a1a] rounded-2xl p-4 border border-white/5">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-lg">{prog.title}</h3>
                    <button onClick={() => { setEditingProgram({ ...prog }); setShowProgramEditor(true); }} className="p-2 hover:bg-white/10 rounded-lg">
                      <Edit3 className="w-4 h-4 text-gray-400" />
                    </button>
                  </div>
                  <p className="text-sm text-gray-500 mb-4">{prog.exercises?.length || 0} упражнений</p>
                  <button onClick={() => startWorkout(prog)} className="w-full bg-blue-500 hover:bg-blue-600 text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors">
                    <Play className="w-5 h-5" />Начать тренировку
                  </button>
                </div>
              ))}
            </div>
          )}

          {workoutHistory.length > 0 && (
            <div>
              <h2 className="text-lg font-semibold mb-3">Последние тренировки</h2>
              <div className="space-y-2">
                {workoutHistory.slice(0, 5).map(w => (
                  <div key={w.id} onClick={() => setViewingWorkout(w)} className="bg-[#1a1a1a] rounded-xl p-4 flex items-center justify-between cursor-pointer hover:bg-[#222] transition-colors border border-white/5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
                        <Dumbbell className="w-5 h-5 text-blue-400" />
                      </div>
                      <div>
                        <p className="font-medium">{w.programTitle}</p>
                        <p className="text-xs text-gray-500">{new Date(w.date).toLocaleDateString('ru-RU')}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-blue-400">{formatTime(w.duration)}</p>
                      <p className="text-xs text-gray-500">{Math.round(w.volume)} кг</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* МАРКЕТ */}
      {activeTab === 'market' && (
        <div className={`p-4 ${activeWorkout && workoutMinimized ? 'pt-20' : ''}`}>
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold">Маркет</h1>
            <div className="flex items-center gap-2 bg-yellow-500/20 px-3 py-2 rounded-full">
              <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
              <span className="font-bold text-yellow-500">{userBalance}</span>
            </div>
          </div>

          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#1a1a1a] pl-10 pr-4 py-3 rounded-xl outline-none border border-white/10 focus:border-blue-500"
              placeholder="Поиск программ..." />
          </div>

          {userRole === 'user' && (
            <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-2xl p-4 mb-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-green-500/30 rounded-xl flex items-center justify-center">
                  <UserCheck className="w-6 h-6 text-green-500" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-green-400">Стань тренером!</h3>
                  <p className="text-sm text-gray-400">Продавай свои программы</p>
                </div>
                <button onClick={submitTrainerRequest} className="bg-green-500 text-white px-4 py-2 rounded-lg font-medium">Подать</button>
              </div>
            </div>
          )}

          <div className="flex gap-2 mb-4 overflow-x-auto pb-2 scrollbar-hide">
            {['Все', 'Масса', 'Похудение', 'Сила', 'Выносливость'].map(cat => (
              <button key={cat} onClick={() => setMarketFilter(cat)}
                className={`px-4 py-2 rounded-full text-sm whitespace-nowrap transition-colors ${marketFilter === cat ? 'bg-blue-500 text-white' : 'bg-[#1a1a1a] text-gray-300 hover:bg-[#222]'}`}>
                {cat}
              </button>
            ))}
          </div>

          <div className="space-y-4">
            {filteredMarket.map(prog => (
              <div key={prog.id} className="bg-[#1a1a1a] rounded-2xl p-4 border border-white/5">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-lg">{prog.title}</h3>
                      {prog.isPro && <Crown className="w-4 h-4 text-yellow-500" />}
                    </div>
                    <p className="text-sm text-gray-500 flex items-center gap-1">
                      {prog.author}
                      <BadgeCheck className="w-4 h-4 text-blue-500" />
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 mb-3">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    <span className="text-sm">{prog.rating}</span>
                  </div>
                  <span className="text-gray-600">•</span>
                  <span className="text-sm text-gray-500">{prog.reviews} отзывов</span>
                  <span className="text-gray-600">•</span>
                  <span className="text-sm text-gray-500">{prog.exercises?.length || 0} упр.</span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="text-xl font-bold flex items-center gap-1">
                    {prog.price === 0 ? (
                      <span className="text-green-500">Бесплатно</span>
                    ) : (
                      <><Star className="w-5 h-5 text-yellow-500 fill-yellow-500" /><span>{prog.price}</span></>
                    )}
                  </div>
                  <button onClick={() => purchaseProgram(prog)}
                    className="bg-blue-500 hover:bg-blue-600 text-white font-medium px-5 py-2 rounded-xl flex items-center gap-2 transition-colors">
                    {prog.price === 0 ? 'Получить' : <><Star className="w-4 h-4" />Купить</>}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ЧАТ ПОДДЕРЖКИ */}
      {activeTab === 'support' && (
        <div className={`flex flex-col h-screen ${activeWorkout && workoutMinimized ? 'pt-16' : ''}`}>
          <div className="p-4 border-b border-white/10">
            <h1 className="text-xl font-bold flex items-center gap-2">
              <MessageCircle className="w-6 h-6 text-blue-500" />
              Техподдержка
            </h1>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {getUserMessages(user?.id).map(msg => (
              <div key={msg.id} className={`flex ${msg.from === 'support' ? 'justify-start' : 'justify-end'}`}>
                <div className={`max-w-[80%] rounded-2xl p-3 ${msg.from === 'support' ? 'bg-blue-500/20 text-blue-100' : 'bg-[#1a1a1a]'}`}>
                  {msg.from === 'support' && <p className="text-xs text-blue-400 mb-1">Поддержка</p>}
                  <p>{msg.text}</p>
                  <p className="text-xs text-gray-500 mt-1">{new Date(msg.date).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}</p>
                </div>
              </div>
            ))}
            {getUserMessages(user?.id).length === 0 && (
              <div className="text-center text-gray-500 py-10">
                <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>Напишите нам, если у вас есть вопросы</p>
              </div>
            )}
          </div>

          <div className="p-4 border-t border-white/10 bg-[#0d0d0d]">
            <div className="flex gap-2">
              <input type="text" value={newMessage} onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendSupportMessage()}
                className="flex-1 bg-[#1a1a1a] px-4 py-3 rounded-xl outline-none border border-white/10 focus:border-blue-500"
                placeholder="Введите сообщение..." />
              <button onClick={sendSupportMessage} className="bg-blue-500 text-white p-3 rounded-xl hover:bg-blue-600 transition-colors">
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ПРОФИЛЬ */}
      {activeTab === 'profile' && (
        <div className={`p-4 ${activeWorkout && workoutMinimized ? 'pt-20' : ''}`}>
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold">Профиль</h1>
            <button
              onClick={() => {
                setProfileDisplayName(user?.displayName || user?.firstName || '');
                setProfileAvatarUrl(user?.avatarUrl || '');
                setShowProfileSettings(true);
              }}
              className="p-2 bg-[#1a1a1a] rounded-xl hover:bg-[#252525] transition-colors"
            >
              <Settings className="w-5 h-5 text-gray-400" />
            </button>
          </div>

          <div className="bg-[#1a1a1a] rounded-2xl p-6 mb-6 text-center border border-white/5">
            {/* Аватар с новогодней шапкой */}
            <div className="relative w-24 h-24 mx-auto mb-4">
              {user?.avatarUrl ? (
                <img
                  src={user.avatarUrl}
                  alt="Avatar"
                  className="w-24 h-24 rounded-full object-cover"
                />
              ) : (
                <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                  <span className="text-4xl font-bold text-white">
                    {(user?.displayName || user?.firstName)?.charAt(0) || 'U'}
                  </span>
                </div>
              )}
              {/* Новогодняя шапка */}
              {showNewYearTheme && (
                <div className="absolute -top-6 -right-3 w-16 h-16 pointer-events-none z-10 filter drop-shadow-lg">
                  <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-12">
                    <circle cx="82" cy="25" r="9" fill="#fff" />
                    <path d="M25 72 Q 55 5 82 25 L 72 40 Q 50 30 35 72 Z" fill="#DC2626" />
                    <rect x="18" y="68" width="55" height="14" rx="7" fill="#fff" transform="rotate(-5 45 75)" />
                  </svg>
                </div>
              )}
            </div>
            <h2 className="text-xl font-bold mb-1">
              {user?.displayName || `${user?.firstName} ${user?.lastName || ''}`}
            </h2>

            {isTrainer && (
              <div className="flex items-center justify-center gap-1 text-blue-400 mb-2">
                <BadgeCheck className="w-5 h-5" />
                <span className="font-medium">Верифицированный тренер</span>
              </div>
            )}

            <p className="text-gray-500">@{user?.username || 'не указан'}</p>

            {isModerator && (
              <span className="inline-block mt-2 bg-purple-500 text-white text-xs font-bold px-3 py-1 rounded-full">
                {isAdmin ? 'ADMIN' : 'MODERATOR'}
              </span>
            )}
          </div>

          <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 rounded-2xl p-4 mb-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <Wallet className="w-8 h-8 text-yellow-500" />
                <div>
                  <p className="text-sm text-gray-400">Баланс</p>
                  <p className="text-2xl font-bold flex items-center gap-1">
                    <Star className="w-6 h-6 text-yellow-500 fill-yellow-500" />{userBalance}
                  </p>
                </div>
              </div>
            </div>
            <div className={`grid gap-3 ${isTrainer ? 'grid-cols-2' : 'grid-cols-1'}`}>
              <button onClick={depositStars} className="bg-green-500/20 text-green-400 py-3 rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-green-500/30 transition-colors">
                <ArrowDownLeft className="w-5 h-5" />Пополнить
              </button>
              {isTrainer && (
                <button onClick={withdrawStars} className="bg-red-500/20 text-red-400 py-3 rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-red-500/30 transition-colors">
                  <ArrowUpRight className="w-5 h-5" />Вывести
                </button>
              )}
            </div>
            {!isTrainer && (
              <p className="text-xs text-gray-500 mt-2 text-center">
                ⭐ Stars используются для покупки программ
              </p>
            )}
          </div>

          {userRole === 'user' && (
            <button onClick={submitTrainerRequest}
              className="w-full bg-green-500/20 border border-green-500/50 rounded-2xl p-4 flex items-center justify-between mb-4 hover:bg-green-500/30 transition-colors">
              <div className="flex items-center gap-3">
                <UserCheck className="w-6 h-6 text-green-500" />
                <span className="text-green-400 font-medium">Стать тренером</span>
              </div>
              <ChevronRight className="w-5 h-5 text-green-500" />
            </button>
          )}

          <div className="bg-[#1a1a1a] rounded-2xl p-4 border border-white/5">
            <h3 className="font-semibold mb-3 text-gray-400">ИНФОРМАЦИЯ</h3>
            <div className="space-y-3">
              <div className="flex justify-between py-2 border-b border-white/5">
                <span className="text-gray-500">Telegram ID</span>
                <span className="font-mono">{user?.id || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-white/5">
                <span className="text-gray-500">Роль</span>
                <span className={`font-medium ${isAdmin ? 'text-purple-400' : userRole === 'moderator' ? 'text-blue-400' : isTrainer ? 'text-green-400' : 'text-gray-400'}`}>
                  {isAdmin ? 'Администратор' : userRole === 'moderator' ? 'Модератор' : isTrainer ? 'Тренер' : 'Пользователь'}
                </span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-gray-500">Программ</span>
                <span>{programs.length + purchasedPrograms.length}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* МОДЕРАЦИЯ */}
      {activeTab === 'moderator' && isModerator && (
        <div className={`p-4 ${activeWorkout && workoutMinimized ? 'pt-20' : ''}`}>
          <h1 className="text-2xl font-bold mb-6">🛡️ Модерация</h1>

          {/* Переключатель новогодней темы */}
          <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-xl p-4 mb-4 border border-blue-500/30 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-2xl">🎄</span>
              <div>
                <p className="font-semibold">Новогодняя тема</p>
                <p className="text-sm text-gray-400">Снежинки для всех пользователей</p>
              </div>
            </div>
            <button
              onClick={async () => {
                const newValue = !showNewYearTheme;
                setShowNewYearTheme(newValue); // Оптимистичное обновление
                try {
                  await fetch(`${API_URL}/settings/new-year-theme`, {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                      'x-telegram-init-data': getInitData(),
                    },
                    body: JSON.stringify({ enabled: newValue }),
                  });
                } catch (e) {
                  console.error('Error updating new year theme:', e);
                  setShowNewYearTheme(!newValue); // Откат при ошибке
                }
              }}
              className={`w-14 h-8 rounded-full transition-colors ${showNewYearTheme ? 'bg-green-500' : 'bg-gray-600'} relative`}
            >
              <span className={`absolute top-1 w-6 h-6 rounded-full bg-white transition-all ${showNewYearTheme ? 'right-1' : 'left-1'}`} />
            </button>
          </div>

          <div className="grid grid-cols-3 gap-3 mb-3">
            <div className="bg-[#1a1a1a] rounded-xl p-3 text-center border border-white/5">
              <div className="text-2xl font-bold text-yellow-500">{trainerRequests.length}</div>
              <div className="text-xs text-gray-500">Заявок</div>
            </div>
            <div className="bg-[#1a1a1a] rounded-xl p-3 text-center border border-white/5">
              <div className="text-2xl font-bold text-blue-500">{getUniqueChatUsers().length}</div>
              <div className="text-xs text-gray-500">Чатов</div>
            </div>
            <div className="bg-[#1a1a1a] rounded-xl p-3 text-center border border-white/5">
              <div className="text-2xl font-bold text-green-500">{rolesList.length}</div>
              <div className="text-xs text-gray-500">Ролей</div>
            </div>
          </div>

          {/* Статистика активности */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="bg-[#1a1a1a] rounded-xl p-3 text-center border border-white/5">
              <div className="text-2xl font-bold text-purple-500">{Object.keys(JSON.parse(localStorage.getItem('fitmarket_all_users') || '{}')).length || '—'}</div>
              <div className="text-xs text-gray-500">Всего польз.</div>
            </div>
            <div className="bg-[#1a1a1a] rounded-xl p-3 text-center border border-white/5">
              <div className="text-2xl font-bold text-cyan-500">{programs.length}</div>
              <div className="text-xs text-gray-500">Программ</div>
            </div>
            <div className="bg-[#1a1a1a] rounded-xl p-3 text-center border border-white/5">
              <div className="text-2xl font-bold text-orange-500">{withdrawalRequests.length}</div>
              <div className="text-xs text-gray-500">Выводов</div>
            </div>
          </div>

          <div className="mb-6">
            <h2 className="font-semibold mb-3 text-gray-400">ЗАЯВКИ НА ТРЕНЕРА</h2>
            {trainerRequests.length === 0 ? (
              <div className="bg-[#1a1a1a] rounded-xl p-4 text-center text-gray-500 border border-white/5">Нет заявок</div>
            ) : (
              <div className="space-y-3">
                {trainerRequests.map(req => (
                  <div key={req.id} className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <p className="font-semibold">{req.firstName} {req.lastName}</p>
                        <p className="text-sm text-gray-500">@{req.username || 'нет'} • ID: {req.userId}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => approveTrainer(req.id)} className="flex-1 bg-green-500 text-white py-2 rounded-lg font-medium hover:bg-green-600 transition-colors">Одобрить</button>
                      <button onClick={() => rejectTrainer(req.id)} className="flex-1 bg-red-500/20 text-red-500 py-2 rounded-lg font-medium hover:bg-red-500/30 transition-colors">Отклонить</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="mb-6">
            <h2 className="font-semibold mb-3 text-gray-400">ЧАТЫ ПОДДЕРЖКИ</h2>
            {getUniqueChatUsers().length === 0 ? (
              <div className="bg-[#1a1a1a] rounded-xl p-4 text-center text-gray-500 border border-white/5">Нет сообщений</div>
            ) : (
              <div className="space-y-2">
                {getUniqueChatUsers().map(chatUser => {
                  const msgs = getUserMessages(chatUser.id);
                  const lastMsg = msgs[msgs.length - 1];
                  return (
                    <div key={chatUser.id} onClick={() => setActiveChatUser(chatUser)}
                      className="bg-[#1a1a1a] rounded-xl p-4 flex items-center justify-between cursor-pointer hover:bg-[#222] transition-colors border border-white/5">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-500/20 rounded-full flex items-center justify-center">
                          <User className="w-5 h-5 text-blue-400" />
                        </div>
                        <div>
                          <p className="font-medium">{chatUser.name}</p>
                          <p className="text-sm text-gray-500 truncate max-w-[200px]">{lastMsg?.text}</p>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-gray-500" />
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {isAdmin && (
            <div className="mb-6">
              <h2 className="font-semibold mb-3 text-gray-400">👑 УПРАВЛЕНИЕ РОЛЯМИ</h2>

              {/* Секция Модераторов */}
              <div className="bg-[#1a1a1a] rounded-xl p-4 border border-purple-500/20 mb-4">
                <h3 className="font-semibold text-purple-400 mb-3 flex items-center gap-2">
                  <Shield className="w-4 h-4" /> Модераторы
                </h3>

                {/* Текущие модераторы */}
                <div className="space-y-2 mb-4">
                  {rolesList.filter(r => r.roles?.includes('MODERATOR') || r.roles?.includes('ADMIN') || r.role === 'ADMIN').length === 0 ? (
                    <p className="text-sm text-gray-500 py-2">Нет назначенных модераторов</p>
                  ) : (
                    rolesList.filter(r => r.roles?.includes('MODERATOR') || r.roles?.includes('ADMIN') || r.role === 'ADMIN').map((r) => (
                      <div key={`mod-${r.telegramId || r.telegram_id}`} className="flex items-center justify-between py-2 px-3 bg-[#0d0d0d] rounded-lg">
                        <div className="flex items-center gap-2">
                          <span className={`w-2 h-2 ${r.roles?.includes('ADMIN') ? 'bg-yellow-500' : 'bg-purple-500'} rounded-full`}></span>
                          <div>
                            <p className="font-semibold text-sm">{r.firstName || r.first_name || 'Пользователь'} {r.lastName || r.last_name || ''}</p>
                            <div className="flex items-center gap-1">
                              <p className="font-mono text-xs text-gray-500">ID: {r.telegramId || r.telegram_id}</p>
                              {r.roles?.includes('TRAINER') && (
                                <span className="text-xs bg-green-500/20 text-green-400 px-1 py-0.5 rounded">+тренер</span>
                              )}
                            </div>
                          </div>
                          {r.roles?.includes('ADMIN') && (
                            <span className="text-xs bg-yellow-500/20 text-yellow-400 px-2 py-0.5 rounded ml-2">👑 Главный</span>
                          )}
                        </div>
                        {!r.roles?.includes('ADMIN') && (
                          <button onClick={() => removeModeratorRole(r.telegramId || r.telegram_id)}
                            className="bg-red-500 text-white px-3 py-1 rounded-lg text-xs hover:bg-red-600 transition-colors flex items-center gap-1">
                            <Trash2 className="w-3 h-3" /> Снять
                          </button>
                        )}
                      </div>
                    ))
                  )}
                </div>

                {/* Назначить модератора */}
                <div className="pt-3 border-t border-white/10">
                  <p className="text-xs text-gray-500 mb-2">Назначить нового:</p>
                  <div className="flex gap-2">
                    <input type="number" placeholder="Telegram ID" className="flex-1 bg-[#0d0d0d] px-3 py-2 rounded-lg outline-none border border-white/10 focus:border-purple-500 text-sm" id="mod-id-input" />
                    <button onClick={() => {
                      const input = document.getElementById('mod-id-input');
                      if (input.value) {
                        setUserAsModerator(input.value);
                        input.value = '';
                      } else {
                        showToast('Введите Telegram ID', 'error');
                      }
                    }} className="bg-purple-500 text-white px-4 py-2 rounded-lg hover:bg-purple-600 transition-colors text-sm font-medium">
                      + Назначить
                    </button>
                  </div>
                </div>
              </div>

              {/* Секция Тренеров */}
              <div className="bg-[#1a1a1a] rounded-xl p-4 border border-green-500/20">
                <h3 className="font-semibold text-green-400 mb-3 flex items-center gap-2">
                  <Dumbbell className="w-4 h-4" /> Тренеры
                </h3>

                {/* Текущие тренеры */}
                <div className="space-y-2 mb-4">
                  {rolesList.filter(r => r.roles?.includes('TRAINER')).length === 0 ? (
                    <p className="text-sm text-gray-500 py-2">Нет назначенных тренеров</p>
                  ) : (
                    rolesList.filter(r => r.roles?.includes('TRAINER')).map((r) => (
                      <div key={`trainer-${r.telegramId || r.telegram_id}`} className="flex items-center justify-between py-2 px-3 bg-[#0d0d0d] rounded-lg">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                          <div>
                            <p className="font-semibold text-sm">{r.firstName || r.first_name || 'Пользователь'} {r.lastName || r.last_name || ''}</p>
                            <div className="flex items-center gap-1">
                              <p className="font-mono text-xs text-gray-500">ID: {r.telegramId || r.telegram_id}</p>
                              {r.roles?.includes('MODERATOR') && (
                                <span className="text-xs bg-purple-500/20 text-purple-400 px-1 py-0.5 rounded">+модератор</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <button onClick={() => removeTrainerRole(r.telegramId || r.telegram_id)}
                          className="bg-red-500 text-white px-3 py-1 rounded-lg text-xs hover:bg-red-600 transition-colors flex items-center gap-1">
                          <Trash2 className="w-3 h-3" /> Снять
                        </button>
                      </div>
                    ))
                  )}
                </div>

                {/* Назначить тренера */}
                <div className="pt-3 border-t border-white/10">
                  <p className="text-xs text-gray-500 mb-2">Назначить нового:</p>
                  <div className="flex gap-2">
                    <input type="number" placeholder="Telegram ID" className="flex-1 bg-[#0d0d0d] px-3 py-2 rounded-lg outline-none border border-white/10 focus:border-green-500 text-sm" id="trainer-id-input" />
                    <button onClick={() => {
                      const input = document.getElementById('trainer-id-input');
                      if (input.value) {
                        setManualTrainer(input.value);
                        input.value = '';
                      } else {
                        showToast('Введите Telegram ID', 'error');
                      }
                    }} className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors text-sm font-medium">
                      + Назначить
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Сброс аккаунта (только для админа) */}
          {isAdmin && (
            <div className="mb-6">
              <h2 className="font-semibold mb-3 text-gray-400">🗑️ СБРОС АККАУНТА</h2>
              <div className="bg-[#1a1a1a] rounded-xl p-4 border border-red-500/20">
                <p className="text-sm text-gray-400 mb-3">Сбросить данные пользователя (баланс, тренировки, программы). Роли сохраняются.</p>
                <div className="flex gap-2">
                  <input
                    type="number"
                    placeholder="Telegram ID для сброса"
                    className="flex-1 bg-[#0d0d0d] px-3 py-2 rounded-lg outline-none border border-white/10 focus:border-red-500 text-sm"
                    id="reset-account-input"
                  />
                  <button onClick={() => {
                    const input = document.getElementById('reset-account-input');
                    if (input.value) {
                      openConfirm(
                        '⚠️ Сброс аккаунта',
                        `Вы уверены что хотите сбросить аккаунт пользователя ${input.value}?\n\nБудут удалены:\n• Баланс\n• История тренировок\n• Программы\n• Купленные программы\n\nРоли (модератор/тренер) сохранятся!`,
                        () => {
                          resetUserAccount(parseInt(input.value));
                          input.value = '';
                        },
                        true,
                        'Сбросить 🔥'
                      );
                    }
                  }} className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors text-sm font-medium">
                    🗑️ Сбросить
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ПУБЛИКАЦИЯ НОВОСТЕЙ */}
          <div className="mb-6">
            <h2 className="font-semibold mb-3 text-gray-400">📰 ПУБЛИКАЦИЯ НОВОСТЕЙ</h2>
            <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
              <input
                type="text"
                placeholder="Заголовок новости"
                className="w-full bg-[#0d0d0d] px-3 py-2 rounded-lg outline-none border border-white/10 focus:border-blue-500 mb-3"
                id="news-title-input"
              />
              <textarea
                placeholder="Текст новости..."
                rows={3}
                className="w-full bg-[#0d0d0d] px-3 py-2 rounded-lg outline-none border border-white/10 focus:border-blue-500 mb-3 resize-none"
                id="news-content-input"
              />
              <button
                onClick={async () => {
                  const titleInput = document.getElementById('news-title-input');
                  const contentInput = document.getElementById('news-content-input');
                  const title = titleInput.value.trim();
                  const content = contentInput.value.trim();

                  if (!title || !content) {
                    showToast('Заполните заголовок и текст новости', 'error');
                    return;
                  }

                  // Создаём на сервере
                  const success = await createNewsOnServer(title, content);
                  if (success) {
                    titleInput.value = '';
                    contentInput.value = '';
                    showToast('✅ Новость опубликована!', 'success');
                  }
                }}
                className="w-full bg-blue-500 text-white py-2 rounded-lg font-medium hover:bg-blue-600 transition-colors"
              >
                📢 Опубликовать новость
              </button>

              {/* Список опубликованных новостей */}
              {news.length > 0 && (
                <div className="mt-4 pt-4 border-t border-white/10">
                  <p className="text-sm text-gray-400 mb-2">Опубликовано: {news.length}</p>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {news.slice().reverse().slice(0, 5).map(item => (
                      <div key={item.id} className="flex items-center justify-between py-2 px-3 bg-[#0d0d0d] rounded-lg">
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{item.title}</p>
                          <p className="text-xs text-gray-500">{new Date(item.createdAt).toLocaleString('ru-RU')}</p>
                        </div>
                        <div className="flex gap-2 ml-2">
                          <button
                            onClick={() => {
                              const newTitle = prompt('Редактировать заголовок:', item.title);
                              if (newTitle === null) return;
                              const newContent = prompt('Редактировать текст:', item.content);
                              if (newContent === null) return;
                              const updated = news.map(n => n.id === item.id ? { ...n, title: newTitle, content: newContent } : n);
                              setNews(updated);
                              // Новости сохраняются через API
                            }}
                            className="text-blue-400 text-xs hover:underline"
                          >
                            Ред.
                          </button>
                          <button
                            onClick={() => {
                              if (!confirm(`Удалить новость "${item.title}"?`)) return;
                              deleteNewsOnServer(item.id);
                            }}
                            className="text-red-500 text-xs hover:underline"
                          >
                            Удалить
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* НАСТРОЙКИ КОМИССИИ (только для админа) */}
          {isAdmin && (
            <div className="mb-6">
              <h2 className="font-semibold mb-3 text-gray-400">💰 НАСТРОЙКИ КОМИССИИ</h2>
              <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="font-medium">Комиссия с вывода</p>
                    <p className="text-sm text-gray-500">С каждого вывода тренера</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="0"
                      max="50"
                      step="0.5"
                      value={withdrawalFee}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value) || 0;
                        setWithdrawalFee(val);
                        // Комиссия хранится только в сессии
                      }}
                      className="w-20 bg-[#0d0d0d] px-3 py-2 rounded-lg text-center outline-none border border-white/10 focus:border-yellow-500"
                    />
                    <span className="text-yellow-500 font-bold">%</span>
                  </div>
                </div>
                <div className="flex items-center justify-between py-3 border-t border-white/10">
                  <div>
                    <p className="text-gray-400">Накоплено с комиссий:</p>
                  </div>
                  <p className="text-xl font-bold text-yellow-500">{adminBalance.toFixed(2)} USDT</p>
                </div>
              </div>
            </div>
          )}

          {/* ВЫВОД СРЕДСТВ (для админа/модератора) */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-semibold text-gray-400">🏦 ВЫВОД СРЕДСТВ</h2>
              <button onClick={fetchAppBalance} className="text-xs text-blue-400 hover:underline">🔄 Обновить</button>
            </div>
            <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
              {/* Баланс CryptoBot */}
              <div className={`flex items-center justify-between p-3 mb-4 rounded-lg ${appBalance !== null && appBalance > 0 ? 'bg-green-500/10 border border-green-500/30' : 'bg-red-500/10 border border-red-500/30'}`}>
                <div>
                  <p className="text-xs text-gray-400">Баланс CryptoBot кошелька:</p>
                  <p className={`text-xl font-bold ${appBalance !== null && appBalance > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {appBalance !== null ? `${appBalance} USDT` : 'Загрузка...'}
                  </p>
                </div>
                {appBalance !== null && appBalance === 0 && (
                  <p className="text-xs text-red-400 max-w-[120px] text-right">⚠️ Нет средств для выплат</p>
                )}
              </div>

              <p className="text-sm text-gray-400 mb-3">Вывести средства на CryptoBot:</p>
              <div className="flex gap-2 mb-4">
                <input
                  type="number"
                  placeholder="Сумма USDT"
                  min="1"
                  step="0.01"
                  className="flex-1 bg-[#0d0d0d] px-3 py-2 rounded-lg outline-none border border-white/10 focus:border-green-500"
                  id="withdraw-amount-input"
                />
                <button
                  onClick={async () => {
                    const input = document.getElementById('withdraw-amount-input');
                    const amount = parseFloat(input.value);
                    if (!amount || amount < 1) {
                      showToast('Минимальная сумма: 1 USDT', 'error');
                      return;
                    }
                    setIsWithdrawing(true);
                    try {
                      const initData = tg?.initData || `user=${encodeURIComponent(JSON.stringify({ id: user?.id || ADMIN_ID, first_name: user?.firstName || 'Admin' }))}`;
                      const response = await fetch('https://fitness-backendnew.onrender.com/api/crypto/withdraw', {
                        method: 'POST',
                        headers: {
                          'Content-Type': 'application/json',
                          'x-telegram-init-data': initData,
                        },
                        body: JSON.stringify({ amount, asset: 'USDT' }),
                      });
                      const data = await response.json();
                      if (data.success) {
                        showToast(`✅ Вывод ${amount} USDT успешно отправлен!`, 'success');
                        input.value = '';
                      } else {
                        throw new Error(data.error || 'Ошибка вывода');
                      }
                    } catch (error) {
                      showToast('❌ ' + error.message, 'error');
                    } finally {
                      setIsWithdrawing(false);
                    }
                  }}
                  disabled={isWithdrawing}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${isWithdrawing ? 'bg-gray-500 cursor-not-allowed' : 'bg-green-500 hover:bg-green-600'} text-white`}
                >
                  {isWithdrawing ? '⏳' : '💸 Вывести'}
                </button>
              </div>
              <p className="text-xs text-gray-500">
                Средства будут отправлены на ваш CryptoBot кошелёк
              </p>
            </div>
          </div>

          {/* ЗАЯВКИ НА ВЫВОД (модерация) */}
          <div className="mb-6">
            <h2 className="font-semibold mb-3 text-gray-400">📋 ЗАЯВКИ НА ВЫВОД</h2>
            {withdrawalRequests.filter(r => r.status === 'pending').length === 0 ? (
              <div className="bg-[#1a1a1a] rounded-xl p-4 text-center text-gray-500 border border-white/5">
                Нет заявок на вывод
              </div>
            ) : (
              <div className="space-y-3">
                {withdrawalRequests.filter(r => r.status === 'pending').map(req => (
                  <div key={req.id} className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <p className="font-semibold">{req.userName}</p>
                        <p className="text-sm text-gray-500">@{req.username || 'нет'} • ID: {req.userId}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-bold text-green-400">{req.amount} USDT</p>
                        <p className="text-xs text-gray-500">
                          Комиссия: {(req.amount * withdrawalFee / 100).toFixed(2)} USDT
                        </p>
                      </div>
                    </div>
                    <p className="text-xs text-gray-500 mb-3">
                      {new Date(req.createdAt).toLocaleString('ru-RU')}
                    </p>
                    <div className="flex gap-2">
                      <button
                        onClick={async () => {
                          if (!confirm(`Одобрить вывод ${req.amount} USDT для ${req.userName}?`)) return;
                          try {
                            const initData = tg?.initData || `user=${encodeURIComponent(JSON.stringify({ id: ADMIN_ID }))}`;
                            const netAmount = req.amount * (1 - withdrawalFee / 100);
                            const feeAmount = req.amount * withdrawalFee / 100;

                            // Отправляем вывод через CryptoBot
                            const response = await fetch('https://fitness-backendnew.onrender.com/api/crypto/withdraw', {
                              method: 'POST',
                              headers: {
                                'Content-Type': 'application/json',
                                'x-telegram-init-data': initData,
                              },
                              body: JSON.stringify({
                                amount: netAmount,
                                asset: 'USDT',
                                targetUserId: req.userId
                              }),
                            });
                            const data = await response.json();

                            if (data.success) {
                              // Обновляем баланс админа от комиссий
                              const newAdminBalance = adminBalance + feeAmount;
                              setAdminBalance(newAdminBalance);
                              // Баланс админа хранится в сессии

                              // Обновляем статус заявки
                              const updated = withdrawalRequests.map(r =>
                                r.id === req.id ? { ...r, status: 'approved', approvedAt: new Date().toISOString() } : r
                              );
                              setWithdrawalRequests(updated);
                              // Заявки хранятся в сессии

                              showToast(`✅ Вывод ${netAmount.toFixed(2)} USDT одобрен! Комиссия: ${feeAmount.toFixed(2)} USDT`, 'success');
                            } else {
                              throw new Error(data.error || 'Ошибка вывода');
                            }
                          } catch (error) {
                            showToast('❌ ' + error.message, 'error');
                          }
                        }}
                        className="flex-1 bg-green-500 text-white py-2 rounded-lg font-medium hover:bg-green-600 transition-colors"
                      >
                        ✅ Одобрить
                      </button>
                      <button
                        onClick={() => {
                          if (!confirm(`Отклонить заявку на вывод от ${req.userName}?`)) return;
                          const updated = withdrawalRequests.map(r =>
                            r.id === req.id ? { ...r, status: 'rejected', rejectedAt: new Date().toISOString() } : r
                          );
                          setWithdrawalRequests(updated);
                          // Заявки хранятся в сессии
                          showToast('❌ Заявка отклонена', 'error');
                        }}
                        className="flex-1 bg-red-500/20 text-red-500 py-2 rounded-lg font-medium hover:bg-red-500/30 transition-colors"
                      >
                        ❌ Отклонить
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Модальное окно чата с пользователем (для модератора) */}
      {activeChatUser && isModerator && (
        <div className="fixed inset-0 bg-black/80 z-50 flex flex-col">
          <div className="p-4 border-b border-white/10 flex items-center justify-between bg-[#0d0d0d]">
            <div className="flex items-center gap-3">
              <button onClick={() => setActiveChatUser(null)} className="text-gray-400">
                <ChevronLeft className="w-6 h-6" />
              </button>
              <div>
                <p className="font-semibold">{activeChatUser.name}</p>
                <p className="text-sm text-gray-500">@{activeChatUser.username}</p>
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#0d0d0d]">
            {getUserMessages(activeChatUser.id).map(msg => (
              <div key={msg.id} className={`flex ${msg.from === 'support' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-2xl p-3 ${msg.from === 'support' ? 'bg-blue-500' : 'bg-[#1a1a1a]'}`}>
                  <p>{msg.text}</p>
                  <p className="text-xs opacity-70 mt-1">{new Date(msg.date).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 border-t border-white/10 bg-[#0d0d0d]">
            <div className="flex gap-2">
              <input type="text" className="flex-1 bg-[#1a1a1a] px-4 py-3 rounded-xl outline-none border border-white/10 focus:border-blue-500"
                placeholder="Ответить..." id="mod-reply-input"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && e.target.value) {
                    sendModeratorReply(activeChatUser.id, e.target.value);
                    e.target.value = '';
                  }
                }} />
              <button onClick={() => {
                const input = document.getElementById('mod-reply-input');
                if (input.value) { sendModeratorReply(activeChatUser.id, input.value); input.value = ''; }
              }} className="bg-blue-500 text-white p-3 rounded-xl hover:bg-blue-600 transition-colors">
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ПАНЕЛЬ ТРЕНЕРА */}
      {activeTab === 'trainer' && canSeeTrainerPanel && (
        <div className={`p-4 ${activeWorkout && workoutMinimized ? 'pt-20' : ''}`}>
          <h1 className="text-2xl font-bold mb-6">💪 Панель тренера</h1>

          {/* Создание программы */}
          <div className="mb-6">
            <h2 className="font-semibold mb-3 text-gray-400">📝 СОЗДАТЬ ПРОГРАММУ</h2>
            <div className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
              <input
                type="text"
                placeholder="Название программы"
                className="w-full bg-[#0d0d0d] px-3 py-2 rounded-lg outline-none border border-white/10 focus:border-green-500 mb-3"
                id="trainer-prog-title"
              />
              <textarea
                placeholder="Описание программы..."
                rows={2}
                className="w-full bg-[#0d0d0d] px-3 py-2 rounded-lg outline-none border border-white/10 focus:border-green-500 mb-3 resize-none"
                id="trainer-prog-desc"
              />
              <select
                className="w-full bg-[#0d0d0d] px-3 py-2 rounded-lg outline-none border border-white/10 mb-3"
                id="trainer-prog-category"
              >
                <option value="Масса">Масса</option>
                <option value="Похудение">Похудение</option>
                <option value="Сила">Сила</option>
                <option value="Выносливость">Выносливость</option>
                <option value="Другое">Другое</option>
              </select>
              <div className="flex gap-3 mb-3">
                <label className="flex items-center gap-2">
                  <input type="radio" name="prog-price-type" value="free" defaultChecked onChange={() => document.getElementById('trainer-prog-price').disabled = true} />
                  <span className="text-gray-400">Бесплатно</span>
                </label>
                <label className="flex items-center gap-2">
                  <input type="radio" name="prog-price-type" value="paid" onChange={() => document.getElementById('trainer-prog-price').disabled = false} />
                  <span className="text-gray-400">Платно</span>
                </label>
                <input
                  type="number"
                  placeholder="Цена USDT"
                  disabled
                  className="flex-1 bg-[#0d0d0d] px-3 py-2 rounded-lg outline-none border border-white/10 focus:border-yellow-500 disabled:opacity-50"
                  id="trainer-prog-price"
                />
              </div>

              {/* Упражнения */}
              <div className="mb-4">
                <p className="text-sm text-gray-400 mb-2">Упражнения:</p>
                <div className="space-y-2 mb-3">
                  {newProgramExercises.map((ex, i) => (
                    <div key={i} className="bg-[#0d0d0d] p-3 rounded-lg space-y-2">
                      <div className="flex items-center gap-2">
                        {ex.isCustom ? (
                          <input
                            type="text"
                            value={ex.name}
                            onChange={(e) => {
                              const updated = [...newProgramExercises];
                              updated[i].name = e.target.value;
                              setNewProgramExercises(updated);
                            }}
                            placeholder="Введите название упражнения"
                            className="flex-1 bg-[#1a1a1a] px-3 py-2 rounded-lg outline-none text-sm border border-white/10"
                          />
                        ) : (
                          <select
                            value={ex.name}
                            onChange={(e) => {
                              const updated = [...newProgramExercises];
                              if (e.target.value === '__custom__') {
                                updated[i].name = '';
                                updated[i].isCustom = true;
                              } else {
                                updated[i].name = e.target.value;
                              }
                              setNewProgramExercises(updated);
                            }}
                            className="flex-1 bg-[#1a1a1a] px-3 py-2 rounded-lg outline-none text-sm border border-white/10"
                          >
                            <option value="">Выберите упражнение</option>
                            {Object.entries(EXERCISE_LIST).map(([category, exercises]) => (
                              <optgroup key={category} label={category}>
                                {exercises.map(name => (
                                  <option key={name} value={name}>{name}</option>
                                ))}
                              </optgroup>
                            ))}
                            <option value="__custom__">📝 Другое (ввести вручную)</option>
                          </select>
                        )}
                        <button
                          onClick={() => setNewProgramExercises(newProgramExercises.filter((_, idx) => idx !== i))}
                          className="text-red-500 p-2"
                        >
                          ✕
                        </button>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <span className="text-xs text-gray-500">Подходы:</span>
                          <input
                            type="number"
                            value={ex.sets}
                            onChange={(e) => {
                              const updated = [...newProgramExercises];
                              updated[i].sets = parseInt(e.target.value) || 0;
                              setNewProgramExercises(updated);
                            }}
                            className="w-14 bg-[#1a1a1a] px-2 py-1 rounded text-center text-sm"
                          />
                        </div>
                        <span className="text-gray-500">×</span>
                        <div className="flex items-center gap-1">
                          <span className="text-xs text-gray-500">Повторы:</span>
                          <input
                            type="text"
                            value={ex.reps}
                            onChange={(e) => {
                              const updated = [...newProgramExercises];
                              updated[i].reps = e.target.value;
                              setNewProgramExercises(updated);
                            }}
                            className="w-16 bg-[#1a1a1a] px-2 py-1 rounded text-center text-sm"
                            placeholder="10-12"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <button
                  onClick={() => setNewProgramExercises([...newProgramExercises, { name: '', sets: 3, reps: '10', isCustom: false }])}
                  className="w-full bg-[#0d0d0d] text-blue-400 py-2 rounded-lg text-sm border border-dashed border-blue-500/30 hover:bg-blue-500/10"
                >
                  + Добавить упражнение
                </button>
              </div>

              <button
                onClick={async () => {
                  const title = document.getElementById('trainer-prog-title').value.trim();
                  const description = document.getElementById('trainer-prog-desc').value.trim();
                  const category = document.getElementById('trainer-prog-category').value;
                  const priceInput = document.getElementById('trainer-prog-price');
                  const isFree = priceInput.disabled;
                  const price = isFree ? 0 : parseFloat(priceInput.value) || 0;

                  if (!title) {
                    showToast('Укажите название программы', 'error');
                    return;
                  }

                  // Создаём на сервере
                  const success = await createProgramOnServer({
                    title,
                    description,
                    category,
                    price,
                    exercises: newProgramExercises.filter(e => e.name.trim()),
                  });

                  if (success) {
                    document.getElementById('trainer-prog-title').value = '';
                    document.getElementById('trainer-prog-desc').value = '';
                    setNewProgramExercises([]);
                    showToast('✅ Программа создана!', 'success');
                  }
                }}
                className="w-full bg-green-500 text-white py-3 rounded-lg font-medium hover:bg-green-600 transition-colors"
              >
                ➕ Создать программу
              </button>
            </div>
          </div>

          {/* Мои программы */}
          <div className="mb-6">
            <h2 className="font-semibold mb-3 text-gray-400">📚 МОИ ПРОГРАММЫ</h2>
            {programs.filter(p => p.authorId === user?.id).length === 0 ? (
              <div className="bg-[#1a1a1a] rounded-xl p-4 text-center text-gray-500 border border-white/5">
                У вас пока нет программ
              </div>
            ) : (
              <div className="space-y-3">
                {programs.filter(p => p.authorId === user?.id).map(prog => (
                  <div key={prog.id} className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="font-semibold">{prog.title}</p>
                        <p className="text-xs text-gray-500">{prog.category} • {prog.price > 0 ? `${prog.price} USDT` : 'Бесплатно'}</p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setEditingProgram(prog)}
                          className="p-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            openConfirm('Удаление', `Удалить программу "${prog.title}"?`, () => deleteProgramOnServer(prog.id), true, 'Удалить');
                          }}
                          className="p-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    {prog.description && <p className="text-sm text-gray-400">{prog.description}</p>}
                    {prog.exercises?.length > 0 && (
                      <p className="text-xs text-green-400 mt-1">💪 {prog.exercises.length} упражнений</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Статистика тренера */}
          <div className="bg-gradient-to-br from-green-500/20 to-blue-500/20 rounded-2xl p-4 border border-green-500/20">
            <h3 className="font-semibold mb-3 flex items-center gap-2"><TrendingUp className="w-5 h-5 text-green-400" />Ваша статистика</h3>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-green-400">{programs.filter(p => p.authorId === user?.id).length}</div>
                <div className="text-xs text-gray-400">Программ</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-400">0</div>
                <div className="text-xs text-gray-400">Продаж</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-yellow-400">{userBalance}</div>
                <div className="text-xs text-gray-400">Заработано</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* МОДАЛЬНОЕ ОКНО УВЕДОМЛЕНИЙ */}
      {showNotificationsModal && (
        <div className="fixed inset-0 bg-black/80 z-50 flex flex-col">
          <div className="p-4 border-b border-white/10 flex items-center justify-between bg-[#0d0d0d]">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Bell className="w-6 h-6 text-blue-500" />
              Уведомления
            </h2>
            <button onClick={() => setShowNotificationsModal(false)} className="text-gray-400 hover:text-white">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 bg-[#0d0d0d]">
            {/* Новости */}
            {news.length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-semibold text-gray-400 mb-3">📰 НОВОСТИ</h3>
                <div className="space-y-3">
                  {news.slice().reverse().map(item => (
                    <div key={item.id} className="bg-[#1a1a1a] rounded-xl p-4 border border-white/5">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-semibold text-blue-400">{item.title}</p>
                          <p className="text-gray-300 mt-1">{item.content}</p>
                        </div>
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        {new Date((item.createdAt || item.created_at)).toLocaleString('ru-RU')}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Персональные уведомления */}
            {notifications.filter(n => n.userId === user?.id).length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-semibold text-gray-400 mb-3">🔔 ЛИЧНЫЕ УВЕДОМЛЕНИЯ</h3>
                <div className="space-y-3">
                  {notifications.filter(n => n.userId === user?.id).slice().reverse().map(item => (
                    <div key={item.id} className={`bg-[#1a1a1a] rounded-xl p-4 border ${item.type === 'success' ? 'border-green-500/30' : item.type === 'error' ? 'border-red-500/30' : 'border-white/5'}`}>
                      <div className="flex items-start justify-between">
                        <p className={`${item.type === 'success' ? 'text-green-400' : item.type === 'error' ? 'text-red-400' : 'text-gray-300'}`}>
                          {item.message}
                        </p>
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        {new Date(item.createdAt).toLocaleString('ru-RU')}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Пусто */}
            {news.length === 0 && notifications.filter(n => n.userId === user?.id).length === 0 && (
              <div className="text-center text-gray-500 py-12">
                <Bell className="w-12 h-12 mx-auto mb-4 opacity-30" />
                <p>Нет уведомлений</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* НАВИГАЦИЯ */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#0d0d0d]/95 backdrop-blur border-t border-white/10 px-2 py-2 z-40">
        <div className="flex justify-around">
          <button onClick={() => setActiveTab('home')} className={`flex flex-col items-center p-2 rounded-xl transition-colors ${activeTab === 'home' ? 'text-blue-500' : 'text-gray-500'}`}>
            <Home className="w-6 h-6" /><span className="text-xs mt-1">Главная</span>
          </button>
          <button onClick={() => setActiveTab('market')} className={`flex flex-col items-center p-2 rounded-xl transition-colors ${activeTab === 'market' ? 'text-blue-500' : 'text-gray-500'}`}>
            <ShoppingBag className="w-6 h-6" /><span className="text-xs mt-1">Маркет</span>
          </button>
          <button onClick={() => setActiveTab('support')} className={`flex flex-col items-center p-2 rounded-xl transition-colors relative ${activeTab === 'support' ? 'text-blue-500' : 'text-gray-500'}`}>
            <div className="relative">
              <MessageCircle className="w-6 h-6" />
              {userMessages.length > 0 && userMessages[userMessages.length - 1].from === 'support' && userMessages[userMessages.length - 1].id !== lastReadSupportId && (
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse border-2 border-[#0d0d0d]" />
              )}
            </div>
            <span className="text-xs mt-1">Поддержка</span>
          </button>
          <button onClick={() => setActiveTab('profile')} className={`flex flex-col items-center p-2 rounded-xl transition-colors ${activeTab === 'profile' ? 'text-blue-500' : 'text-gray-500'}`}>
            <User className="w-6 h-6" /><span className="text-xs mt-1">Профиль</span>
          </button>
          {canSeeTrainerPanel && (
            <button onClick={() => setActiveTab('trainer')} className={`flex flex-col items-center p-2 rounded-xl transition-colors ${activeTab === 'trainer' ? 'text-green-500' : 'text-gray-500'}`}>
              <Dumbbell className="w-6 h-6" /><span className="text-xs mt-1">Тренер</span>
            </button>
          )}
          {isModerator && (
            <button onClick={() => setActiveTab('moderator')} className={`flex flex-col items-center p-2 rounded-xl transition-colors relative ${activeTab === 'moderator' ? 'text-blue-500' : 'text-gray-500'}`}>
              <Shield className="w-6 h-6" />
              <span className="text-xs mt-1">Модер</span>
              {(trainerRequests.length > 0 || getUniqueChatUsers().length > 0) && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 rounded-full text-xs flex items-center justify-center">
                  {trainerRequests.length + getUniqueChatUsers().length}
                </span>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Модалка результатов тренировки */}
      {workoutSummary && (
        <div className="fixed inset-0 bg-black/90 z-[200] flex items-center justify-center p-4">
          <div className="bg-[#1a1a1a] rounded-3xl w-full max-w-sm p-8 text-center border border-white/10 relative overflow-hidden">
            {/* Конфетти эффект (простой CSS) */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-0 left-1/4 w-2 h-2 bg-yellow-500 rounded-full animate-ping" style={{ animationDuration: '1s' }}></div>
              <div className="absolute top-10 right-1/4 w-2 h-2 bg-blue-500 rounded-full animate-ping" style={{ animationDuration: '1.5s' }}></div>
              <div className="absolute bottom-10 left-10 w-2 h-2 bg-green-500 rounded-full animate-ping" style={{ animationDuration: '2s' }}></div>
            </div>

            <div className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-orange-500/20">
              <Trophy className="w-10 h-10 text-white" />
            </div>

            <h2 className="text-2xl font-bold mb-2 bg-gradient-to-r from-yellow-200 to-amber-500 text-transparent bg-clip-text">Отличная работа!</h2>
            <p className="text-gray-400 mb-8">{workoutSummary.title}</p>

            <div className="grid grid-cols-3 gap-4 mb-8">
              <div className="bg-[#0d0d0d] p-3 rounded-2xl border border-white/5">
                <p className="text-xs text-gray-500 mb-1">Время</p>
                <p className="font-bold text-lg">
                  {Math.floor(workoutSummary.duration / 60)}м {workoutSummary.duration % 60}с
                </p>
              </div>
              <div className="bg-[#0d0d0d] p-3 rounded-2xl border border-white/5">
                <p className="text-xs text-gray-500 mb-1">Объём</p>
                <p className="font-bold text-lg text-green-400">{Math.round(workoutSummary.volume)} <span className="text-xs">кг</span></p>
              </div>
              <div className="bg-[#0d0d0d] p-3 rounded-2xl border border-white/5">
                <p className="text-xs text-gray-500 mb-1">Подходы</p>
                <p className="font-bold text-lg text-blue-400">{workoutSummary.sets}</p>
              </div>
            </div>

            <button
              onClick={() => setWorkoutSummary(null)}
              className="w-full bg-gradient-to-r from-blue-600 to-blue-500 text-white py-4 rounded-xl font-bold text-lg hover:from-blue-500 hover:to-blue-400 transition-all shadow-lg shadow-blue-500/20"
            >
              Продолжить путь 🚀
            </button>
          </div>
        </div>
      )}

      {/* Модалка настроек профиля */}
      {showProfileSettings && (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4" onClick={() => setShowProfileSettings(false)}>
          <div className="bg-[#1a1a1a] rounded-2xl w-full max-w-md p-6 border border-white/10" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold">Настройки профиля</h2>
              <button onClick={() => setShowProfileSettings(false)} className="text-gray-400 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Аватар */}
            <div className="text-center mb-6">
              <div className="relative w-24 h-24 mx-auto mb-3">
                {profileAvatarUrl ? (
                  <img src={profileAvatarUrl} alt="Avatar" className="w-24 h-24 rounded-full object-cover" />
                ) : (
                  <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                    <span className="text-4xl font-bold text-white">
                      {profileDisplayName?.charAt(0) || user?.firstName?.charAt(0) || 'U'}
                    </span>
                  </div>
                )}
                <label className="absolute bottom-0 right-0 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center cursor-pointer hover:bg-blue-600 transition-colors">
                  <Camera className="w-4 h-4 text-white" />
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    onChange={handleAvatarUpload}
                    className="hidden"
                  />
                </label>
              </div>
              <p className="text-xs text-gray-500">Нажмите на камеру чтобы загрузить фото</p>
            </div>

            {/* Имя */}
            <div className="mb-6">
              <label className="block text-sm text-gray-400 mb-2">Отображаемое имя</label>
              <input
                type="text"
                value={profileDisplayName}
                onChange={e => setProfileDisplayName(e.target.value)}
                placeholder="Ваше имя"
                maxLength={50}
                className="w-full bg-[#0d0d0d] px-4 py-3 rounded-xl outline-none border border-white/10 focus:border-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">Минимум 2 символа</p>
            </div>

            {/* Кнопки */}
            <div className="flex gap-3">
              <button
                onClick={() => setShowProfileSettings(false)}
                className="flex-1 py-3 rounded-xl bg-[#252525] text-gray-400 hover:bg-[#303030] transition-colors"
              >
                Отмена
              </button>
              <button
                onClick={saveProfile}
                disabled={profileSaving || profileDisplayName.trim().length < 2}
                className="flex-1 py-3 rounded-xl bg-blue-500 text-white font-medium hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {profileSaving ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Сохранение...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Сохранить
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
