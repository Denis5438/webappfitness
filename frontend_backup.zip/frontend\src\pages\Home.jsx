import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTelegram } from '../hooks/useTelegram';
import { workoutsApi, usersApi } from '../services/api';
import './Home.css';

export default function Home() {
  const navigate = useNavigate();
  const { user, isReady, showMainButton, hideMainButton, hapticFeedback } = useTelegram();
  const [workouts, setWorkouts] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isReady && user) {
      loadData();
    }
  }, [isReady, user]);

  useEffect(() => {
    // Показываем Telegram MainButton только если в Telegram
    if (window.Telegram?.WebApp) {
      showMainButton('Начать тренировку', () => {
        hapticFeedback('medium');
        navigate('/workout/new');
      });

      return () => hideMainButton();
    }
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Создаём/обновляем пользователя
      await usersApi.createUser({
        telegram_id: user.id,
        username: user.username,
        first_name: user.first_name,
        last_name: user.last_name,
      });

      // Загружаем тренировки
      const workoutsRes = await workoutsApi.getWorkouts(user.id, 5);
      setWorkouts(workoutsRes.data);

      // Загружаем статистику
      const statsRes = await workoutsApi.getStats(user.id);
      setStats(statsRes.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Сегодня';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Вчера';
    } else {
      return date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
    }
  };

  if (loading) {
    return (
      <div className="container loading">
        <div className="spinner"></div>
        <p>Загрузка...</p>
      </div>
    );
  }

  return (
    <div className="container">
      <header className="header">
        <h1>💪 Фитнес Дневник</h1>
        <p className="subtitle">Привет, {user?.first_name || 'Атлет'}!</p>
      </header>

      {stats && (
        <div className="stats-card">
          <h2>📊 Статистика</h2>
          <div className="stats-grid">
            <div className="stat-item">
              <div className="stat-value">{stats.total_workouts}</div>
              <div className="stat-label">Тренировок</div>
            </div>
            <div className="stat-item">
              <div className="stat-value">{stats.avg_duration}</div>
              <div className="stat-label">Мин/тренировка</div>
            </div>
          </div>
        </div>
      )}

      <div className="section">
        <div className="section-header">
          <h2>📝 Последние тренировки</h2>
          <button 
            className="link-button"
            onClick={() => navigate('/workouts')}
          >
            Все
          </button>
        </div>

        {workouts.length === 0 ? (
          <div className="empty-state">
            <p>🏋️ Начните свою первую тренировку!</p>
            <button
              onClick={() => navigate('/workout/new')}
              style={{
                width: '100%',
                maxWidth: '300px',
                padding: '16px',
                marginTop: '16px',
                background: '#3390ec',
                color: 'white',
                border: 'none',
                borderRadius: '12px',
                fontSize: '16px',
                fontWeight: '600',
                cursor: 'pointer'
              }}
            >
              Начать тренировку
            </button>
          </div>
        ) : (
          <div className="workouts-list">
            {workouts.map((workout) => (
              <div 
                key={workout.id} 
                className="workout-card"
                onClick={() => navigate(`/workout/${workout.id}`)}
              >
                <div className="workout-header">
                  <span className="workout-date">{formatDate(workout.date)}</span>
                  {workout.duration_minutes && (
                    <span className="workout-duration">⏱ {workout.duration_minutes} мин</span>
                  )}
                </div>
                <div className="workout-exercises">
                  {workout.exercises.slice(0, 3).map((ex, idx) => (
                    <span key={idx} className="exercise-tag">
                      {ex.exercise_name}
                    </span>
                  ))}
                  {workout.exercises.length > 3 && (
                    <span className="exercise-tag more">
                      +{workout.exercises.length - 3}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="section">
        <div className="section-header">
          <h2>🤖 AI Ассистент</h2>
          <button 
            className="link-button"
            onClick={() => navigate('/ai')}
          >
            Открыть
          </button>
        </div>
        <div className="ai-card" onClick={() => navigate('/ai')}>
          <p>💬 Задайте вопрос о тренировках</p>
          <p className="ai-hint">Получите персонализированные советы</p>
        </div>
      </div>
    </div>
  );
}
