import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Users API
export const usersApi = {
  getUser: (telegramId) => api.get(`/users/${telegramId}`),
  createUser: (userData) => api.post('/users', userData),
  updateSubscription: (telegramId, tier) => 
    api.patch(`/users/${telegramId}/subscription`, { tier }),
};

// Workouts API
export const workoutsApi = {
  getWorkouts: (userId, limit = 10) => 
    api.get(`/workouts/${userId}`, { params: { limit } }),
  createWorkout: (workoutData) => api.post('/workouts', workoutData),
  deleteWorkout: (workoutId) => api.delete(`/workouts/${workoutId}`),
  getStats: (userId) => api.get(`/workouts/${userId}/stats`),
};

// AI API
export const aiApi = {
  sendMessage: (userId, message) => 
    api.post('/ai/chat', { user_id: userId, message }),
  getHistory: (userId, limit = 20) => 
    api.get(`/ai/history/${userId}`, { params: { limit } }),
};

export default api;
