import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTelegram } from '../hooks/useTelegram';
import { workoutsApi, usersApi } from '../services/api';
import { Trophy, TrendingUp, Calendar, Plus } from 'lucide-react';
import BottomNav from '../components/BottomNav';

export default function HomeNew() {
  const navigate = useNavigate();
  const { user, isReady } = useTelegram();
  const [workouts, setWorkouts] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isReady && user) {
      loadData();
    }
  }, [isReady, user]);

  const loadData = async () => {
    try {
      setLoading(true);
      
      await usersApi.createUser({
        telegram_id: user.id,
        username: user.username,
        first_name: user.first_name,
        last_name: user.last_name,
      });

      const [workoutsRes, statsRes] = await Promise.all([
        workoutsApi.getWorkouts(user.id, 5),
        workoutsApi.getStats(user.id),
      ]);

      setWorkouts(workoutsRes.data);
      setStats(statsRes.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500">Загрузка...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="app bg-gray-50 min-h-screen">
      {/* Header */}
      <header className="bg-white px-4 py-4 mb-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">
            Fit<span className="text-primary">Market</span>
          </h1>
          <div className="flex gap-2">
            <button className="px-4 py-2 rounded-lg border border-gray-200 text-sm font-medium">
              Атлет
            </button>
            <button className="px-4 py-2 rounded-lg bg-gray-100 text-sm font-medium">
              Тренер
            </button>
          </div>
        </div>
      </header>

      <div className="px-4 space-y-4">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <div className="text-3xl font-bold text-gray-900">{stats?.total_workouts || 0}</div>
            <div className="text-sm text-gray-500 mt-1">Тренировок</div>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <div className="text-3xl font-bold text-gray-900">
              {stats?.avg_duration ? Math.round(stats.avg_duration) : 0}
            </div>
            <div className="text-sm text-gray-500 mt-1">Мин/день</div>
          </div>
        </div>

        {/* Records Section */}
        <section className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <Trophy className="w-5 h-5 text-yellow-500" />
            <h2 className="text-lg font-bold">Твои рекорды</h2>
          </div>
          
          {workouts.length > 0 ? (
            <div className="space-y-3">
              {workouts.slice(0, 3).map((workout) => (
                <div key={workout.id} className="border border-gray-100 rounded-xl p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-gray-900">
                      {workout.exercises?.[0]?.exercise_name || 'Тренировка'}
                    </span>
                    <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-md font-medium">
                      PR
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="bg-gray-50 rounded-lg p-2 text-center">
                      <div className="text-xl font-bold text-gray-900">
                        {workout.exercises?.[0]?.sets_data?.[0]?.weight || 0} кг
                      </div>
                      <div className="text-xs text-gray-500">Вес</div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-2 text-center">
                      <div className="text-xl font-bold text-gray-900">
                        {workout.exercises?.[0]?.sets_data?.[0]?.reps || 0}
                      </div>
                      <div className="text-xs text-gray-500">Повторений</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-400">
              <Trophy className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>Пока нет рекордов</p>
            </div>
          )}

          <button
            onClick={() => navigate('/workout/new')}
            className="w-full mt-4 py-3 border-2 border-primary text-primary rounded-xl font-semibold flex items-center justify-center gap-2 hover:bg-primary hover:text-white transition-colors"
          >
            <Plus className="w-5 h-5" />
            Добавить новый результат
          </button>
        </section>

        {/* Today's Plan */}
        <section className="bg-white rounded-2xl p-4 shadow-sm mb-20">
          <h2 className="text-lg font-bold mb-4">План на сегодня</h2>
          
          {workouts.length > 0 ? (
            <div className="space-y-3">
              {workouts.slice(0, 1).map((workout) => (
                <div key={workout.id} className="border border-gray-100 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-gray-900">
                      День {workout.id}: {workout.exercises?.[0]?.muscle_group || 'Тренировка'}
                    </h3>
                    <span className="text-sm text-gray-500">
                      {workout.duration_minutes || 60} мин
                    </span>
                  </div>
                  <ol className="space-y-1 text-sm text-gray-600">
                    {workout.exercises?.map((ex, idx) => (
                      <li key={idx}>
                        {idx + 1}. {ex.exercise_name} ({ex.sets_data?.length || 0} подходов)
                      </li>
                    ))}
                  </ol>
                  <button
                    onClick={() => navigate('/workout/new')}
                    className="w-full mt-4 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-primary-dark transition-colors"
                  >
                    Начать тренировку
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Calendar className="w-12 h-12 mx-auto mb-2 text-gray-300" />
              <p className="text-gray-400 mb-4">План на сегодня пуст</p>
              <button
                onClick={() => navigate('/workout/new')}
                className="px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-primary-dark transition-colors"
              >
                Создать тренировку
              </button>
            </div>
          )}
        </section>
      </div>

      <BottomNav />
    </div>
  );
}
